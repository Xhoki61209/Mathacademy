# Petunjuk deployment MathLevel Academy

## Pilihan A — GitHub Pages (subdomain gratis)

Hasil akhirnya biasanya berupa `https://NAMA-AKUN.github.io/NAMA-REPOSITORY/`. Nama akun dan repository ditentukan di akun GitHub milik pemilik website.

1. Buat repository baru di GitHub.
2. Unggah isi folder ini ke root repository, termasuk `.github/workflows/pages.yml` dan folder `tests`.
3. Pastikan branch utama bernama `main`.
4. Buka **Settings → Pages** pada repository, lalu pilih sumber deployment **GitHub Actions**.
5. Buka tab **Actions** dan pantau workflow `Deploy MathLevel Academy to GitHub Pages`.
6. Setelah workflow berhasil, buka URL `page_url` dari hasil deployment.
7. Uji dashboard, pelajaran pertama, kuis, hasil, progres setelah refresh, halaman profil, dan tampilan mobile.

Workflow menjalankan pemeriksaan sintaks, tes logika/data, audit 65 kunci jawaban, dan simulasi profil bot sebelum deployment. Jika tes gagal, langkah publikasi tidak dilanjutkan.

## Pilihan B — Cloudflare Pages (subdomain pages.dev)

1. Buat akun Cloudflare dan repository GitHub, jika belum ada.
2. Di Cloudflare Dashboard, pilih Workers & Pages → Create → Pages → Connect to Git.
3. Pilih repository dan branch.
4. Karena ini situs statis tanpa bundler, gunakan konfigurasi build minimal/kosong sesuai pilihan UI dan tetapkan build output directory ke root repository (`.`). Jika UI mewajibkan direktori output, pastikan output berisi `index.html`, `styles.css`, `core.js`, `catalog.js`, dan `app.js`.
5. Deploy dan uji URL `*.pages.dev` yang diberikan.

Cloudflare Pages dapat memakai file `_headers` di paket ini. Dukungan header berbeda menurut penyedia hosting.

## Sebelum membagikan website

- Jangan unggah file `.env` atau token rahasia ke repository.
- Pastikan semua file proyek ikut diunggah.
- Uji HTTPS serta URL yang benar-benar diberikan layanan hosting.
- Ingat bahwa profil dan progres pada versi statis ini hanya tersimpan di browser lokal pengguna.
- Untuk akun sungguhan dan progres sinkron antarperangkat, proyek perlu backend autentikasi/database (misalnya Supabase) yang dikonfigurasi dan diuji secara terpisah.

## Status domain

Paket ini menyediakan konfigurasi agar dapat diterbitkan pada subdomain gratis dari layanan hosting. Domain publik belum dapat dibuat atas nama pemilik tanpa akses yang diotorisasi ke akun penyedia hosting/repository. Jangan mengklaim URL sudah aktif sampai URL hasil deployment dibuka dan diverifikasi.
