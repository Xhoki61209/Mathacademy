'use strict';
const assert = require('node:assert/strict');
const Core = require('../core.js');
const Catalog = require('../catalog.js');
let checks = 0;
function check(condition, message) { assert.ok(condition, message); checks++; }
function equal(a,b,message) { assert.equal(a,b,message); checks++; }
function deep(a,b,message) { assert.deepEqual(a,b,message); checks++; }

// 1. Static catalogue integrity.
const ids = Catalog.map(l => l.id);
equal(new Set(ids).size, ids.length, 'Lesson IDs must be unique');
check(ids.length >= 8, 'At least eight lessons should be included');
check(Catalog.some(l=>l.track==='wajib') && Catalog.some(l=>l.track==='lanjut'), 'Both tracks must exist');
for (const lesson of Catalog) {
  check(Number.isInteger(lesson.order) && lesson.order > 0, `Valid order: ${lesson.id}`);
  check(lesson.questions.length >= 5, `At least five questions: ${lesson.id}`);
  check(lesson.objectives.length >= 1, `Objectives included: ${lesson.id}`);
  check(lesson.concepts.length >= 1, `Concepts included: ${lesson.id}`);
  check(lesson.examples.length >= 3, `Three example tiers: ${lesson.id}`);
  const qids = lesson.questions.map(q=>q.id);
  equal(new Set(qids).size, qids.length, `Question IDs unique in ${lesson.id}`);
  for(const q of lesson.questions){
    equal(q.choices.length,5,`A-E choice count: ${q.id}`);
    check(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<5,`Correct answer index: ${q.id}`);
    check(q.choices.every(c=>typeof c==='string'&&c.length>0),`Nonempty choices: ${q.id}`);
    check(typeof q.explanation==='string'&&q.explanation.length>10,`Explanation exists: ${q.id}`);
    check(typeof q.prompt==='string'&&q.prompt.length>5,`Question prompt exists: ${q.id}`);
  }
}
// 2. Progression invariants.
const completed = new Set();
for(const track of ['wajib','lanjut']){
  const ordered=Catalog.filter(l=>l.track===track).sort((a,b)=>a.order-b.order);
  check(Core.isUnlocked(ordered[0],Catalog,completed),`First level unlocked for ${track}`);
  for(let i=1;i<ordered.length;i++) check(!Core.isUnlocked(ordered[i],Catalog,completed),`Future level locked for ${track}, order ${i+1}`);
  ordered.forEach((lesson,index)=>{
    if(index>0) completed.add(ordered[index-1].id);
    equal(Core.isUnlocked(lesson,Catalog,completed),true,`Sequential unlock: ${lesson.id}`);
  });
  // reset only the track before testing the other track does not matter for separate track constraints.
}
// 3. Score and threshold property checks.
for (const lesson of Catalog) {
  const allCorrect=lesson.questions.map(q=>({questionId:q.id,selectedIndex:q.answer}));
  equal(Core.calculateScore(allCorrect,lesson.questions),100,`All correct score 100: ${lesson.id}`);
  const allWrong=lesson.questions.map(q=>({questionId:q.id,selectedIndex:(q.answer+1)%5}));
  equal(Core.calculateScore(allWrong,lesson.questions),0,`All wrong score 0: ${lesson.id}`);
  const fourCorrect=lesson.questions.slice(0,4).map(q=>({questionId:q.id,selectedIndex:q.answer}));
  const oneWrong={questionId:lesson.questions[4].id,selectedIndex:(lesson.questions[4].answer+1)%5};
  const score80=Core.calculateScore(fourCorrect.concat(oneWrong),lesson.questions);
  equal(score80,80,`Four of five score 80: ${lesson.id}`);
  check(Core.isPassing(score80),`80% passes threshold: ${lesson.id}`);
  check(!Core.isPassing(60),`60% does not pass: ${lesson.id}`);
  equal(Core.calculateScore([],lesson.questions),0,`Empty attempt scores zero: ${lesson.id}`);
  equal(Core.calculateScore(allCorrect,[]),0,'No-question quiz scores zero');
}
// 4. Deterministic fuzz checks: answer permutations, malformed storage, XP idempotence, and progress bounds.
let seed=0x4d415448;
function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
for(let i=0;i<1500;i++){
  const lesson=Catalog[Math.floor(rand()*Catalog.length)];
  const answers=lesson.questions.map(q=>({questionId:q.id,selectedIndex:Math.floor(rand()*5)}));
  const score=Core.calculateScore(answers,lesson.questions);
  check(Number.isInteger(score)&&score>=0&&score<=100,`Fuzz score bounded at iteration ${i}`);
  const valid=Core.sanitizeState({xp:Math.floor(rand()*10000),streak:Math.floor(rand()*30),completedLessons:lessonIdsMaybe(lesson),profile:{name:` Test   ${i} `},todayQuestions:['q1','q1',null],dailyGoal:[5,10,15,20][Math.floor(rand()*4)]},new Set(ids));
  check(Number.isFinite(valid.xp)&&valid.xp>=0,`Fuzz state XP sanitized at ${i}`);
  check(valid.profile.name.length>0&&valid.profile.name.length<=32,`Fuzz profile sanitized at ${i}`);
  check(valid.completedLessons.every(id=>ids.includes(id)),`Fuzz completed IDs validated at ${i}`);
  check([5,10,15,20].includes(valid.dailyGoal),`Fuzz daily goal constrained at ${i}`);
  const initial={xp:0,earnedQuestionXp:[]};
  const r1=Core.uniqueXp(initial,'same-key',2);
  const r2=Core.uniqueXp(initial,'same-key',2);
  equal(r1.added,2,`First XP award at ${i}`);
  equal(r2.added,0,`Duplicate XP award prevented at ${i}`);
  equal(initial.xp,2,`XP cannot double count at ${i}`);
  const prog=Core.calculateTrackProgress(Catalog,lesson.track,valid.completedLessons);
  check(Number.isInteger(prog)&&prog>=0&&prog<=100,`Progress bounded at ${i}`);
}
function lessonIdsMaybe(lesson){return rand()>.5?[lesson.id,'bogus-id',lesson.id]:['bogus-id'];}
// 5. Date and streak checks.
const streakState={streak:0,lastStudyDate:'',studyDates:[]};
equal(Core.markStudyDay(streakState,'2026-01-01').streak,1,'First study day starts streak');
equal(Core.markStudyDay(streakState,'2026-01-01').streak,1,'Same date does not increase streak');
equal(Core.markStudyDay(streakState,'2026-01-02').streak,2,'Consecutive date increases streak');
equal(Core.markStudyDay(streakState,'2026-01-05').streak,1,'Gap resets streak');
equal(Core.dayDifference('2026-01-01','2026-01-02'),1,'Day difference checks adjacent dates');
equal(Core.dayDifference('invalid','2026-01-02'),NaN,'Invalid day date returns NaN');
// 6. Normalization/security-ish boundaries.
equal(Core.normalizeName('  <script>alert(1)</script>  ').includes('<'),false,'Profile name strips angle brackets');
equal(Core.normalizeName('   '),'','Blank profile names remain blank for validation');
equal(Core.normalizeName('A'.repeat(80)).length,32,'Profile name length bounded');
const corrupt=Core.sanitizeState('not an object',new Set(ids));
check(corrupt && typeof corrupt==='object' && corrupt.profile.name==='Siswa','Malformed local state falls back safely');
const unknown=Core.sanitizeState({completedLessons:['invalid-id'],attempts:[{lessonId:'invalid-id',score:100}],xp:-10,profile:{name:''}},new Set(ids));
equal(unknown.completedLessons.length,0,'Unknown lesson IDs removed');
equal(unknown.attempts.length,0,'Unknown attempt lesson IDs removed');
equal(unknown.xp,0,'Negative XP sanitized');
console.log(JSON.stringify({status:'PASS',checks,lessons:Catalog.length,questions:Catalog.reduce((n,l)=>n+l.questions.length,0),fuzzIterations:1500},null,2));
