'use strict';
const assert = require('node:assert/strict');
const Catalog = require('../catalog.js');
const expectedCorrectChoice = {
  wb1:'5', wb2:'11/12', wb3:'32', wb4:'1/5', wb5:'10',
  wg1:'30 cm²', wg2:'5', wg3:'14π cm', wg4:'10 cm', wg5:'10 m',
  wa1:'6x − 7', wa2:'x² + x − 6', wa3:'(x + 3)(x + 4)', wa4:'−a + 12', wa5:'(2x + 1)(2x − 7)',
  wk1:'2 dan 3', wk2:'7/2', wk3:'3', wk4:'Tidak memiliki akar real', wk5:'3',
  wf1:'5', wf2:'x ≥ 2', wf3:'y ≥ 0', wf4:'5', wf5:'2',
  ws1:'6', ws2:'9', ws3:'1/2', ws4:'1/3', ws5:'3',
  wt1:'1/2', wt2:'1/2', wt3:'180°', wt4:'3/5', wt5:'sin²x + cos²x = 1',
  lm1:'5', lm2:'[[3, 3], [4, 3]]', lm3:'[[1, −1], [−1, 2]]', lm4:'Determinan sama dengan nol', lm5:'A memiliki invers',
  lp1:'(x − 2)(x − 3)', lp2:'9', lp3:'5', lp4:'x − 1', lp5:'2',
  lf1:'x ≠ 2', lf2:'2x + 6', lf3:'180°', lf4:'f(x) ≥ 0', lf5:'amplitudo saja',
  lv1:'5', lv2:'(4, 1)', lv3:'−1', lv4:'(−1, −5)', lv5:'90',
  lt1:'(5, 3)', lt2:'(2, 5)', lt3:'90', lt4:'(−4, 6)', lt5:'sumbu-x',
  ll1:'6', ll2:'4', ll3:'13', ll4:'2', ll5:'−4'
};
let checks=0;const ids=new Set();
for(const lesson of Catalog){for(const q of lesson.questions){
  assert.ok(!ids.has(q.id),`Question ID must be globally unique: ${q.id}`);ids.add(q.id);checks++;
  assert.equal(new Set(q.choices).size,5,`Choices should not have exact duplicates: ${q.id}`);checks++;
  assert.ok(Object.hasOwn(expectedCorrectChoice,q.id),`Manual answer audit expected: ${q.id}`);checks++;
  assert.equal(q.choices[q.answer],expectedCorrectChoice[q.id],`Correct option key manually cross-checked: ${q.id}`);checks++;
}}
assert.equal(ids.size,Object.keys(expectedCorrectChoice).length,'Every manually audited question must exist');checks++;
console.log(JSON.stringify({status:'PASS',checks,manuallyAuditedAnswerKeys:ids.size},null,2));
