'use strict';
const assert=require('node:assert/strict');
const Core=require('../core.js');
const Catalog=require('../catalog.js');
let checks=0;function ok(value,message){assert.ok(value,message);checks++;}function eq(a,b,message){assert.equal(a,b,message);checks++;}
const validIds=new Set(Catalog.map(l=>l.id));
let seed=0x51A7E;
function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
function shuffle(input){const out=[...input];for(let i=out.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
function runSimulatedUser(userNo){
  let state=Core.getDefaultState();state.profile.name=`Bot ${userNo}`;
  const initialXp=state.xp;
  // No user should gain access to a future level before its prerequisite is completed.
  for(const track of ['wajib','lanjut']){
    const list=Catalog.filter(l=>l.track===track).sort((a,b)=>a.order-b.order);
    eq(Core.isUnlocked(list[0],Catalog,state.completedLessons),true,`bot ${userNo}: first ${track} level open`);
    for(let lockedIdx=1;lockedIdx<list.length;lockedIdx++)eq(Core.isUnlocked(list[lockedIdx],Catalog,state.completedLessons),false,`bot ${userNo}: ${list[lockedIdx].id} starts locked before prerequisite`);
    for(let idx=0;idx<list.length;idx++){
      const lesson=list[idx];
      eq(Core.isUnlocked(lesson,Catalog,state.completedLessons),true,`bot ${userNo}: current level ${lesson.id} unlocked`);
      // Simulate the student completing each lesson with answers in a different order.
      const answers=shuffle(lesson.questions).map(q=>({questionId:q.id,selectedIndex:q.answer}));
      eq(Core.calculateScore(answers,lesson.questions),100,`bot ${userNo}: correct quiz is 100% on ${lesson.id}`);
      ok(Core.isPassing(Core.calculateScore(answers,lesson.questions)),`bot ${userNo}: correct quiz passes ${lesson.id}`);
      const qRewardKeys=lesson.questions.map(q=>`question:${q.id}`);
      for(let j=0;j<qRewardKeys.length;j++){
        const award=Core.uniqueXp(state,qRewardKeys[j],2);
        eq(award.added,2,`bot ${userNo}: first question XP awarded ${lesson.questions[j].id}`);
        eq(Core.uniqueXp(state,qRewardKeys[j],2).added,0,`bot ${userNo}: duplicate question XP blocked ${lesson.questions[j].id}`);
      }
      const before=state.xp;
      state.completedLessons.push(lesson.id);
      const levelReward=Core.uniqueXp(state,`level:${lesson.id}`,10);
      eq(levelReward.added,10,`bot ${userNo}: level completion bonus awarded ${lesson.id}`);
      eq(Core.uniqueXp(state,`level:${lesson.id}`,10).added,0,`bot ${userNo}: duplicate level bonus blocked ${lesson.id}`);
      ok(state.xp>before,`bot ${userNo}: XP increases after successful completion`);
      if(idx+1<list.length)eq(Core.isUnlocked(list[idx+1],Catalog,state.completedLessons),true,`bot ${userNo}: next level unlocks after completion`);
    }
  }
  eq(state.completedLessons.length,Catalog.length,`bot ${userNo}: full course completion`);
  eq(Core.calculateTrackProgress(Catalog,'wajib',state.completedLessons),100,`bot ${userNo}: wajib progress 100%`);
  eq(Core.calculateTrackProgress(Catalog,'lanjut',state.completedLessons),100,`bot ${userNo}: lanjut progress 100%`);
  ok(state.xp>initialXp,`bot ${userNo}: final XP greater than initial XP`);
  eq(Core.sanitizeState(state,validIds).completedLessons.length,Catalog.length,`bot ${userNo}: persisted state roundtrip retains completion`);
  // A separate failed attempt with two incorrect answers must not pass the 80% threshold.
  const lesson=Catalog[Math.floor(rand()*Catalog.length)];
  const wrongAnswers=lesson.questions.map((q,i)=>({questionId:q.id,selectedIndex:i<2?(q.answer+1)%5:q.answer}));
  const score=Core.calculateScore(wrongAnswers,lesson.questions);
  eq(score,60,`bot ${userNo}: two incorrect answers produce 60%`);
  eq(Core.isPassing(score),false,`bot ${userNo}: 60% does not pass`);
}
for(let user=1;user<=100;user++)runSimulatedUser(user);
// Randomized invalid inputs should remain bounded and must not inject unknown lesson IDs.
for(let i=0;i<2000;i++){
  const raw={xp:Math.round(rand()*1e10),streak:Math.round(rand()*1e6),completedLessons:Array.from({length:Math.floor(rand()*10)},()=>rand()>.5?Catalog[Math.floor(rand()*Catalog.length)].id:'attacker-id'),profile:{name:`Bot <${i}>`},dailyGoal:[-100,5,10,15,20,999][Math.floor(rand()*6)]};
  const clean=Core.sanitizeState(raw,validIds);
  ok(Number.isSafeInteger(clean.xp)&&clean.xp>=0&&clean.xp<=100000000,`fuzz ${i}: XP sanitized`);
  ok(clean.completedLessons.every(id=>validIds.has(id)),`fuzz ${i}: unknown levels filtered`);
  ok([5,10,15,20].includes(clean.dailyGoal),`fuzz ${i}: daily goal constrained`);
  ok(clean.profile.name.length<=32&&!clean.profile.name.includes('<'),`fuzz ${i}: profile name sanitized`);
}
console.log(JSON.stringify({status:'PASS',checks,simulatedUsers:100,completeCourseRuns:100,randomizedSanitizationCases:2000,notes:'Deterministic state/logic simulations; not real human users or full browser E2E.'},null,2));
