'use strict';
const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');let checks=0;
function ok(v,m){assert.ok(v,m);checks++;}function eq(a,b,m){assert.equal(a,b,m);checks++;}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const core=fs.readFileSync(path.join(root,'core.js'),'utf8');
const catalog=fs.readFileSync(path.join(root,'catalog.js'),'utf8');
// Local runtime assets referenced by the entry HTML must exist.
for(const match of html.matchAll(/(?:src|href)="([^"#][^"]*)"/g)){
  const value=match[1];if(/^https?:\/\//i.test(value)||value.startsWith('mailto:'))continue;
  const local=path.join(root,value.split('?')[0]);ok(fs.existsSync(local),`local asset exists: ${value}`);
}
// Avoid runtime CDN dependencies for scripts/styles.
ok(!/<script[^>]+src="https?:\/\//i.test(html),'No external runtime script CDN');
ok(!/<link[^>]+rel="stylesheet"[^>]+href="https?:\/\//i.test(html),'No external runtime stylesheet CDN');
// Entry page IDs must be unique.
const idMatches=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);eq(new Set(idMatches).size,idMatches.length,'Unique static HTML IDs');
// Ensure CSS structural braces are balanced after removing comments.
const noComments=css.replace(/\/\*[\s\S]*?\*\//g,'');eq((noComments.match(/{/g)||[]).length,(noComments.match(/}/g)||[]).length,'CSS braces balanced');
// Check all authored UI action names have a delegated handler.
const authored=new Set([...(`${html}\n${app}`).matchAll(/data-action=\\?["']([^"']+)\\?["']/g)].map(m=>m[1]));
const handled=new Set([...app.matchAll(/action===['"]([^'"]+)['"]/g)].map(m=>m[1]));
for(const action of authored)ok(handled.has(action),`data-action has a handler: ${action}`);
// Check required stable elements and storage key.
for(const id of ['sidebar','top-streak','top-xp','top-avatar','topbar-section','app-content','toast-region','year'])ok(html.includes(`id="${id}"`),`required shell element ${id}`);
ok(core.includes("'mathlevel-academy-state-v1'"),'Versioned storage key exists');
ok(catalog.includes('TKA · Penalaran'),'Catalog includes reasoning-oriented questions');
// Security-related output must escape profile text before rendering.
ok(app.includes('Core.normalizeName(state.profile.name)')||app.includes('esc(state.profile.name)'),'Profile output sanitized');
ok(!/service_role|SUPABASE_SERVICE_ROLE_KEY|BEGIN PRIVATE KEY|sk-[A-Za-z0-9]{20,}/.test([html,app,core,catalog].join('\n')),'No obvious secret key pattern');
console.log(JSON.stringify({status:'PASS',checks,localReferences:'checked',actionHandlers:authored.size,staticHtmlIds:idMatches.length},null,2));
