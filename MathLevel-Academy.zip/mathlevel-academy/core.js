/* MathLevel Core v1 — dependency-free, deterministic learning rules. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.MathLevelCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const STORAGE_KEY = 'mathlevel-academy-state-v1';
  const PASS_THRESHOLD = 80;
  const DEFAULT_PROFILE = Object.freeze({ name: 'Siswa', grade: 'Kelas XI', goal: 'TKA SMA' });

  function clamp(value, min, max) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : min;
  }
  function normalizeName(value) {
    return String(value == null ? '' : value).replace(/[<>\u0000-\u001f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 32);
  }
  function toSafeInt(value, fallback, max) {
    const n = Number(value);
    return Number.isSafeInteger(n) && n >= 0 ? Math.min(n, max == null ? 1_000_000_000 : max) : fallback;
  }
  function getDefaultState() {
    return {
      schemaVersion: 1,
      profile: { name: DEFAULT_PROFILE.name, grade: DEFAULT_PROFILE.grade, goal: DEFAULT_PROFILE.goal },
      xp: 0,
      streak: 0,
      lastStudyDate: '',
      studyDates: [],
      completedLessons: [],
      attempts: [],
      earnedQuestionXp: [],
      unlockedAchievements: [],
      dailyGoal: 15,
      todayQuestions: [],
      questionGoalDate: '',
      minutesToday: 0,
      createdAt: new Date().toISOString()
    };
  }
  function sanitizeState(raw, validLessonIds) {
    const defaults = getDefaultState();
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return defaults;
    const validIds = validLessonIds instanceof Set ? validLessonIds : new Set(Array.isArray(validLessonIds) ? validLessonIds : []);
    const srcProfile = raw.profile && typeof raw.profile === 'object' ? raw.profile : {};
    const profileName = normalizeName(srcProfile.name) || DEFAULT_PROFILE.name;
    const grade = ['Kelas X', 'Kelas XI', 'Kelas XII', 'Lainnya'].includes(srcProfile.grade) ? srcProfile.grade : DEFAULT_PROFILE.grade;
    const goal = ['Fondasi matematika', 'TKA SMA', 'Pendalaman materi'].includes(srcProfile.goal) ? srcProfile.goal : DEFAULT_PROFILE.goal;
    const stringList = (list, allowAll) => Array.isArray(list) ? [...new Set(list.filter(v => typeof v === 'string' && (allowAll || validIds.has(v))).slice(0, 5000))] : [];
    const attempts = Array.isArray(raw.attempts) ? raw.attempts.filter(a => a && typeof a === 'object' && validIds.has(a.lessonId) && Number.isFinite(Number(a.score)) && Number(a.score) >= 0 && Number(a.score) <= 100).slice(-100) : [];
    const studyDates = Array.isArray(raw.studyDates) ? [...new Set(raw.studyDates.filter(d => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)))].slice(-400) : [];
    return {
      schemaVersion: 1,
      profile: { name: profileName, grade, goal },
      xp: toSafeInt(raw.xp, 0, 100_000_000),
      streak: toSafeInt(raw.streak, 0, 100_000),
      lastStudyDate: typeof raw.lastStudyDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.lastStudyDate) ? raw.lastStudyDate : '',
      studyDates,
      completedLessons: stringList(raw.completedLessons, false),
      attempts,
      earnedQuestionXp: stringList(raw.earnedQuestionXp, true),
      unlockedAchievements: stringList(raw.unlockedAchievements, true),
      dailyGoal: [5, 10, 15, 20].includes(Number(raw.dailyGoal)) ? Number(raw.dailyGoal) : 15,
      todayQuestions: stringList(raw.todayQuestions, true).slice(-500),
      questionGoalDate: typeof raw.questionGoalDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.questionGoalDate) ? raw.questionGoalDate : '',
      minutesToday: clamp(raw.minutesToday || 0, 0, 1440),
      createdAt: typeof raw.createdAt === 'string' ? raw.createdAt : defaults.createdAt
    };
  }
  function calculateScore(answers, questions) {
    if (!Array.isArray(questions) || questions.length === 0) return 0;
    const answerMap = new Map((Array.isArray(answers) ? answers : []).filter(a => a && typeof a.questionId === 'string').map(a => [a.questionId, a.selectedIndex]));
    const correct = questions.reduce((sum, q) => sum + (answerMap.has(q.id) && answerMap.get(q.id) === q.answer ? 1 : 0), 0);
    return Math.round((correct / questions.length) * 100);
  }
  function isPassing(score, threshold) {
    const t = threshold == null ? PASS_THRESHOLD : clamp(threshold, 0, 100);
    return Number.isFinite(Number(score)) && Number(score) >= t;
  }
  function getPreviousLesson(lesson, lessons) {
    const sameTrack = (Array.isArray(lessons) ? lessons : []).filter(l => l && l.track === lesson.track).sort((a, b) => a.order - b.order);
    const index = sameTrack.findIndex(l => l.id === lesson.id);
    return index > 0 ? sameTrack[index - 1] : null;
  }
  function isUnlocked(lessonOrId, lessons, completedIds) {
    const list = Array.isArray(lessons) ? lessons : [];
    const lesson = typeof lessonOrId === 'string' ? list.find(l => l.id === lessonOrId) : lessonOrId;
    if (!lesson || !Array.isArray(completedIds) && !(completedIds instanceof Set)) return false;
    const done = completedIds instanceof Set ? completedIds : new Set(completedIds);
    const prerequisite = getPreviousLesson(lesson, list);
    return !prerequisite || done.has(prerequisite.id);
  }
  function calculateTrackProgress(lessons, track, completedIds) {
    const subset = (Array.isArray(lessons) ? lessons : []).filter(l => l.track === track);
    if (!subset.length) return 0;
    const done = completedIds instanceof Set ? completedIds : new Set(Array.isArray(completedIds) ? completedIds : []);
    return Math.round(subset.filter(l => done.has(l.id)).length / subset.length * 100);
  }
  function uniqueXp(state, key, amount) {
    const safeState = state && typeof state === 'object' ? state : getDefaultState();
    const earned = new Set(Array.isArray(safeState.earnedQuestionXp) ? safeState.earnedQuestionXp : []);
    if (earned.has(key)) return { added: 0, xp: toSafeInt(safeState.xp, 0), alreadyEarned: true };
    const points = toSafeInt(amount, 0, 10000);
    earned.add(key);
    safeState.earnedQuestionXp = Array.from(earned);
    safeState.xp = toSafeInt(safeState.xp, 0) + points;
    return { added: points, xp: safeState.xp, alreadyEarned: false };
  }
  function localDateKey(date) {
    const d = date instanceof Date ? date : new Date();
    if (!Number.isFinite(d.getTime())) return '';
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  function dayDifference(a, b) {
    const parse = s => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(s || '')) return NaN;
      const [y, m, d] = s.split('-').map(Number);
      return Date.UTC(y, m - 1, d);
    };
    const aa = parse(a), bb = parse(b);
    return Number.isFinite(aa) && Number.isFinite(bb) ? Math.round((bb - aa) / 86400000) : NaN;
  }
  function markStudyDay(state, dateKey) {
    const s = state && typeof state === 'object' ? state : getDefaultState();
    const today = /^\d{4}-\d{2}-\d{2}$/.test(dateKey || '') ? dateKey : localDateKey();
    const dates = new Set(Array.isArray(s.studyDates) ? s.studyDates : []);
    if (dates.has(today)) return { streak: toSafeInt(s.streak, 0), changed: false, today };
    const diff = dayDifference(s.lastStudyDate, today);
    s.streak = !s.lastStudyDate ? 1 : diff === 1 ? toSafeInt(s.streak, 0) + 1 : diff === 0 ? toSafeInt(s.streak, 0) : 1;
    s.lastStudyDate = today;
    dates.add(today);
    s.studyDates = [...dates].sort().slice(-400);
    return { streak: s.streak, changed: true, today };
  }
  function getLessonStatus(lesson, lessons, state) {
    const completed = new Set(state && Array.isArray(state.completedLessons) ? state.completedLessons : []);
    if (completed.has(lesson.id)) return 'completed';
    if (isUnlocked(lesson, lessons, completed)) return 'available';
    return 'locked';
  }
  return Object.freeze({ STORAGE_KEY, PASS_THRESHOLD, DEFAULT_PROFILE, clamp, normalizeName, getDefaultState, sanitizeState, calculateScore, isPassing, getPreviousLesson, isUnlocked, calculateTrackProgress, uniqueXp, localDateKey, dayDifference, markStudyDay, getLessonStatus });
});
