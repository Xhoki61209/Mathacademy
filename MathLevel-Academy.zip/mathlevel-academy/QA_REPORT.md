# QA Report — MathLevel Academy

Tanggal pengujian: 26 Oktober 2026.

## Hasil pemeriksaan yang dijalankan

| Pemeriksaan | Hasil |
|---|---:|
| Modul pembelajaran | 13 |
| Soal pilihan ganda | 65 |
| Opsi per soal | 5 (A–E) |
| Tes logika/data otomatis | 14.036 pemeriksaan lulus |
| Audit pilihan jawaban manual terdokumentasi | 65 kunci lulus |
| Simulasi profil bot | 100 profil menyelesaikan jalur simulasi |
| Kasus sanitasi acak deterministik | 2.000 |
| Audit aset/handler/CSS statis | 38 pemeriksaan lulus |
| Total pemeriksaan terprogram di empat suite | 46.235 lulus |
| `node --check` untuk app/core/catalog | lulus |

Pengujian otomatis mencakup bentuk data katalog, ID unik, keberadaan tujuan pembelajaran dan contoh, jumlah opsi, rentang kunci jawaban, pembahasan, perhitungan skor (0%, 80%, 100%), aturan ambang kelulusan, pembukaan level, pembatasan XP ganda, sanitasi data tersimpan, progres 0–100%, nama profil, target soal harian, dan perhitungan streak.

## Batas cakupan

Angka pemeriksaan di atas berasal dari tiga suite tes terprogram di lingkungan Node.js, termasuk 100 simulasi profil bot yang menyelesaikan urutan level dan 2.000 kasus sanitasi. Itu bukan jumlah pengguna nyata, bukan jaminan semua kombinasi UI/perangkat bebas bug, dan bukan pengganti audit matematika independen terhadap seluruh materi.

Percobaan Chromium headless di lingkungan kerja ini tidak dapat membuka `file://` atau URL loopback lokal karena kebijakan browser lingkungan menolaknya. Karena itu, tes interaksi browser end-to-end belum dapat dinyatakan lulus. Jalankan smoke test pada preview/deployment yang diizinkan sebelum menyatakan rilis produksi.

## Item penting yang diketahui

- Ini adalah MVP frontend statis. Penyimpanan menggunakan `localStorage`, tidak memakai autentikasi server, dan tidak menyinkronkan pengguna antargawai.
- Pembukaan level di frontend tidak memberikan keamanan anti-kecurangan yang layak untuk ujian berisiko tinggi.
- Materi awal perlu diperluas dan diverifikasi terhadap dokumen resmi terbaru sebelum dianggap sebagai cakupan lengkap TKA.
