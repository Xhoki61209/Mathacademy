(function () {
  'use strict';
  const Core = window.MathLevelCore;
  const Catalog = window.MathLevelCatalog;
  if (!Core || !Catalog) {
    document.getElementById('app-content').innerHTML = '<div class="empty-state"><strong>Aplikasi belum siap</strong>Muat ulang halaman. Jika masalah berulang, periksa file core.js dan catalog.js.</div>';
    return;
  }
  const content = document.getElementById('app-content');
  const lessonIds = new Set(Catalog.map(l => l.id));
  let state = loadState();
  let page = 'dashboard';
  let selectedTrack = 'wajib';
  let currentLessonId = null;
  let quizSession = null;
  let lastResult = null;
  let libraryQuery = '';
  let libraryTrack = 'all';
  let libraryStatus = 'all';
  let toastTimer = null;

  function loadState() {
    try {
      const raw = localStorage.getItem(Core.STORAGE_KEY);
      return Core.sanitizeState(raw ? JSON.parse(raw) : Core.getDefaultState(), lessonIds);
    } catch (error) {
      return Core.getDefaultState();
    }
  }
  function saveState() {
    try {
      localStorage.setItem(Core.STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch (error) {
      showToast('Penyimpanan perangkat penuh atau diblokir. Progres mungkin tidak bertahan setelah halaman ditutup.', 'error');
      return false;
    }
  }
  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function initials(name) {
    const safe = Core.normalizeName(name) || 'Siswa';
    return safe.split(' ').filter(Boolean).slice(0, 2).map(s => s[0].toUpperCase()).join('') || 'S';
  }
  function todayKey() { return Core.localDateKey(new Date()); }
  function completedSet() { return new Set(state.completedLessons); }
  function isCompleted(lessonId) { return state.completedLessons.includes(lessonId); }
  function getLesson(id) { return Catalog.find(l => l.id === id) || null; }
  function lessonStatus(lesson) { return Core.getLessonStatus(lesson, Catalog, state); }
  function isUnlocked(lesson) { return Core.isUnlocked(lesson, Catalog, state.completedLessons); }
  function getNextLesson(track) {
    const list = Catalog.filter(l => l.track === track).sort((a,b)=>a.order-b.order);
    return list.find(l => !isCompleted(l.id) && isUnlocked(l)) || list.find(l=>!isCompleted(l.id)) || null;
  }
  function getSuggestedLesson() {
    const selected = getNextLesson(selectedTrack);
    if (selected && !isCompleted(selected.id) && isUnlocked(selected)) return selected;
    return Catalog.find(l => !isCompleted(l.id) && isUnlocked(l)) || Catalog.find(l => !isCompleted(l.id)) || null;
  }
  function trackLabel(track) { return track === 'wajib' ? 'Matematika Wajib' : 'Matematika Tingkat Lanjut'; }
  function trackBadge(track) { return `<span class="track-badge ${track === 'wajib' ? 'wajib' : 'lanjut'}">${track === 'wajib' ? 'WAJIB' : 'TINGKAT LANJUT'}</span>`; }
  function trackSymbol(track) { return track === 'wajib' ? '∑' : 'ƒ(x)'; }
  function progressFor(track) { return Core.calculateTrackProgress(Catalog, track, state.completedLessons); }
  function currentQuestionCount() { return state.attempts.reduce((sum, a) => sum + (Number(a.total) || 0), 0); }
  function questionGoalProgress() {
    const today = todayKey();
    const arr = Array.isArray(state.todayQuestions) && state.questionGoalDate === today ? state.todayQuestions : [];
    return arr.length;
  }
  function updateGlobalChrome() {
    document.getElementById('top-streak').textContent = String(state.streak || 0);
    document.getElementById('top-xp').textContent = `${state.xp || 0} XP`;
    document.getElementById('top-avatar').textContent = initials(state.profile.name);
    document.getElementById('year').textContent = String(new Date().getFullYear());
    const names = {dashboard:'Dashboard',path:'Peta level',library:'Materi & latihan',progress:'Progres belajar',profile:'Profil siswa',lesson:'Materi belajar',quiz:'Arena latihan',result:'Hasil evaluasi'};
    document.getElementById('topbar-section').textContent = names[page] || 'Dashboard';
    document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.page === page || ((page === 'lesson' || page === 'quiz' || page === 'result') && ['path','library'].includes(btn.dataset.page) && btn.dataset.page === 'library')));
    document.querySelectorAll('.mobile-nav button').forEach(btn => btn.classList.toggle('active', btn.dataset.page === page || (['lesson','quiz','result'].includes(page) && btn.dataset.page === 'library')));
  }
  function showToast(message, type) {
    const region = document.getElementById('toast-region');
    if (!region) return;
    region.innerHTML = `<div class="toast ${type === 'success' ? 'success' : type === 'error' ? 'error' : ''}" role="status">${esc(message)}</div>`;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { region.innerHTML = ''; }, 3400);
  }
  function render() {
    updateGlobalChrome();
    const renderers = {dashboard:renderDashboard,path:renderPath,library:renderLibrary,progress:renderProgress,profile:renderProfile,lesson:renderLesson,quiz:renderQuiz,result:renderResult};
    (renderers[page] || renderDashboard)();
    content.focus({ preventScroll: true });
    document.getElementById('sidebar').classList.remove('open');
    content.scrollTop = 0;
  }
  function renderDashboard() {
    const next = getSuggestedLesson();
    const total = Catalog.length;
    const done = state.completedLessons.length;
    const goal = Math.min(questionGoalProgress(), Number(state.dailyGoal) || 5);
    const goalTarget = Number(state.dailyGoal) || 5;
    const recent = [...state.attempts].slice(-3).reverse();
    const greeting = new Date().getHours() < 11 ? 'Selamat pagi' : new Date().getHours() < 15 ? 'Selamat siang' : new Date().getHours() < 18 ? 'Selamat sore' : 'Selamat malam';
    const date = new Intl.DateTimeFormat('id-ID', {weekday:'long',day:'numeric',month:'long'}).format(new Date());
    const today = todayKey();
    const todayDate = new Date();
    const week = [];
    for (let i=6;i>=0;i--) { const d = new Date(todayDate); d.setDate(todayDate.getDate()-i); week.push({key:todayKeyFor(d), label:['Min','Sen','Sel','Rab','Kam','Jum','Sab'][d.getDay()], today:todayKeyFor(d)===today, active:(state.studyDates||[]).includes(todayKeyFor(d))}); }
    content.innerHTML = `
      <div class="page-heading"><div><div class="eyebrow">${esc(date)}</div><h1>${greeting}, ${esc(state.profile.name)}.</h1><p>Setiap konsep yang kamu kuasai membawa kamu selangkah lebih maju.</p></div><button class="button button-outline" data-action="navigate" data-page="profile">◎ Profil saya</button></div>
      <div class="grid dashboard-grid">
        <div class="left-stack">
          <section class="hero-card">
            <div class="hero-topline"><span class="hero-dot"></span> PERJALANAN BELAJAR BERIKUTNYA</div>
            <div class="hero-copy"><h1>${next ? esc(next.title) : 'Perjalananmu dimulai di sini'}</h1><p>${next ? `Lanjutkan jalur ${esc(trackLabel(next.track))}. Pelajari konsep, lihat contoh, lalu buktikan pemahamanmu lewat latihan bertahap.` : 'Kamu telah menyelesaikan semua level yang tersedia di versi awal. Kamu bisa meninjau kembali materi dan latihan.'}</p><div class="hero-actions"><button class="button button-primary" data-action="play-next">▶ &nbsp; Bermain sekarang</button><button class="button hero-secondary" data-action="navigate" data-page="path">Lihat peta level&nbsp; ↗</button></div></div>
            <div class="hero-illustration" aria-hidden="true"><svg viewBox="0 0 190 165" fill="none"><circle cx="104" cy="83" r="67" stroke="#c0d8f7" stroke-opacity=".25"/><circle cx="104" cy="83" r="48" stroke="#c0d8f7" stroke-opacity=".34" stroke-dasharray="4 6"/><path d="M54 113L84 91L111 103L140 61" stroke="#9ce7ce" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="54" cy="113" r="7" fill="#a4e8d2" stroke="#fff" stroke-width="2"/><circle cx="84" cy="91" r="7" fill="#a4e8d2" stroke="#fff" stroke-width="2"/><circle cx="111" cy="103" r="7" fill="#a4e8d2" stroke="#fff" stroke-width="2"/><circle cx="140" cy="61" r="9" fill="#e0f8ef" stroke="#fff" stroke-width="2"/><path d="M130 26h26M143 13v26" stroke="#91b7ef" stroke-width="2" stroke-linecap="round"/><rect x="18" y="34" width="43" height="28" rx="7" fill="#fff" fill-opacity=".14" stroke="#fff" stroke-opacity=".25"/><path d="M27 43h25M27 49h17M27 55h20" stroke="#e6f0ff" stroke-width="1.6" stroke-linecap="round"/><rect x="132" y="119" width="37" height="25" rx="6" fill="#fff" fill-opacity=".14" stroke="#fff" stroke-opacity=".24"/><path d="M141 128l6 6 12-12" stroke="#a4e8d2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
          </section>
          <div class="stats-row">
            <div class="stat-card"><div class="stat-icon">⌁</div><div class="stat-info"><strong>${done}/${total}</strong><span>Level selesai</span></div></div>
            <div class="stat-card"><div class="stat-icon green">✓</div><div class="stat-info"><strong>${state.xp}</strong><span>Total XP</span></div></div>
            <div class="stat-card"><div class="stat-icon gold">✦</div><div class="stat-info"><strong>${state.streak}</strong><span>Hari beruntun</span></div></div>
          </div>
          <section class="section-card card-pad">
            <div class="section-head"><div><h2>Perjalanan belajarmu</h2><p>Pilih jalur dan lanjutkan level berikutnya.</p></div><button class="text-link" data-action="navigate" data-page="path">Semua level ↗</button></div>
            <div class="track-tabs"><button class="track-tab ${selectedTrack==='wajib'?'active':''}" data-action="set-track" data-track="wajib">Matematika Wajib</button><button class="track-tab ${selectedTrack==='lanjut'?'active':''}" data-action="set-track" data-track="lanjut">Tingkat Lanjut</button></div>
            <div class="lesson-mini-list">${Catalog.filter(l=>l.track===selectedTrack).slice(0,4).map(l=>miniLesson(l)).join('')}</div>
            <div class="card-footer"><span>${progressFor(selectedTrack)}% dari jalur telah diselesaikan</span><span>${Catalog.filter(l=>l.track===selectedTrack).filter(l=>isCompleted(l.id)).length}/${Catalog.filter(l=>l.track===selectedTrack).length} level</span></div>
          </section>
        </div>
        <div class="right-stack">
          <section class="section-card side-summary">
            <div class="side-summary-head"><h2>Profil belajar</h2><span class="pill-label">SISWA</span></div>
            <div class="profile-summary"><div class="big-avatar">${esc(initials(state.profile.name))}</div><div><strong>${esc(state.profile.name)}</strong><span>${esc(state.profile.grade)} · ${esc(state.profile.goal)}</span></div></div>
            <div class="small-metrics"><div class="small-metric"><strong>${state.xp}</strong><span>Total XP</span></div><div class="small-metric"><strong>${done}</strong><span>Level selesai</span></div></div>
            <div class="daily-goal"><div class="section-head"><h2>Target latihan harian</h2><span>${goal}/${goalTarget} soal</span></div><div class="progress-track"><div class="progress-fill green-fill" style="width:${Math.min(100,goal/goalTarget*100)}%"></div></div><div class="goal-line"><span>Jawab beberapa soal setiap hari</span><strong>${Math.round(Math.min(100,goal/goalTarget*100))}%</strong></div></div>
            <div class="card-footer"><span>Progres tersimpan di perangkat ini</span><button class="text-link" data-action="navigate" data-page="profile">Pengaturan ↗</button></div>
          </section>
          <section class="streak-panel"><div class="streak-panel-top"><div><h3>Ritme belajarmu</h3><p>Konsistensi tumbuh dari langkah kecil.</p></div><div class="streak-big">${state.streak}<span class="tiny"> hari</span></div></div><div class="week-dots">${week.map(d=>`<div class="week-day ${d.active?'active':''} ${d.today?'today':''}"><span>${d.label}</span><span>${d.active?'✓':d.today?'•':'·'}</span></div>`).join('')}</div></section>
          <section class="tip-card"><div class="tip-icon">i</div><div><strong>Strategi belajar</strong><p>Pahami alasan di balik rumus. Setelah satu konsep terasa mudah, lanjutkan ke soal modifikasi dan penalaran.</p></div></section>
          ${recent.length ? `<section class="section-card card-pad"><div class="section-head"><div><h2>Aktivitas terbaru</h2><p>Hasil latihan terakhir</p></div><button class="text-link" data-action="navigate" data-page="progress">Lihat semua</button></div><div class="history-list">${recent.map(renderHistoryItem).join('')}</div></section>` : ''}
        </div>
      </div>
      ${mobileNav()}`;
  }
  function todayKeyFor(d) { return Core.localDateKey(d); }
  function miniLesson(l) {
    const status = lessonStatus(l);
    const statusText = status==='completed'?'Selesai':status==='locked'?'Terkunci':'Mulai';
    return `<button class="lesson-mini" data-action="open-lesson" data-lesson="${l.id}" ${status==='locked'?'aria-label="'+esc(l.title)+' terkunci"':''}><span class="lesson-ordinal ${status==='completed'?'complete':status==='locked'?'locked':''}">${status==='completed'?'✓':status==='locked'?'⌑':String(l.order).padStart(2,'0')}</span><span class="lesson-mini-main"><strong>${esc(l.title)}</strong><span>${esc(l.unit)} · ${l.duration} menit</span></span><span class="mini-status ${status==='completed'?'done':status==='locked'?'lock':''}">${statusText}</span></button>`;
  }
  function renderPath() {
    content.innerHTML = `<div class="page-heading"><div><div class="eyebrow">LEARNING PATH</div><h1>Peta perjalanan belajar</h1><p>Selesaikan satu level untuk membuka level berikutnya di jalur yang sama.</p></div><button class="button button-primary" data-action="play-next">▶ Bermain</button></div>
      <div class="path-grid">${['wajib','lanjut'].map(track=>{
        const lessons = Catalog.filter(l=>l.track===track).sort((a,b)=>a.order-b.order); const done=lessons.filter(l=>isCompleted(l.id)).length; const pct=progressFor(track);
        return `<section class="track-card"><div class="track-card-head"><div class="track-symbol ${track}">${trackSymbol(track)}</div><div><h2>${trackLabel(track)}</h2><p>${track==='wajib'?'Fondasi dan penerapan matematika SMA.':'Pendalaman aljabar, geometri, dan kalkulus.'}</p></div><div class="track-count"><strong>${done}/${lessons.length}</strong><span>level</span></div></div><div class="progress-track"><div class="progress-fill ${track==='lanjut'?'green-fill':''}" style="width:${pct}%"></div></div><div class="progress-meta"><span>Progres jalur</span><strong>${pct}%</strong></div><div class="topic-list">${lessons.map(l=>{
          const st=lessonStatus(l);return `<div class="topic-row"><span class="topic-dot ${st==='completed'?'done':st==='locked'?'locked':''}"></span><div class="topic-row-main"><strong>${String(l.order).padStart(2,'0')}. ${esc(l.title)}</strong><span>${esc(l.unit)} · ${l.questions.length} soal · ${l.duration} menit</span></div>${trackBadge(track)}<button class="topic-open" data-action="open-lesson" data-lesson="${l.id}" ${st==='locked'?'disabled aria-label="Level terkunci"':'aria-label="Buka '+esc(l.title)+'"'}>${st==='completed'?'✓':st==='locked'?'⌑':'→'}</button></div>`}).join('')}</div><div class="card-footer"><span>${done===lessons.length?'Semua level tersedia telah diselesaikan.':`${lessons.length-done} level belum diselesaikan.`}</span><button class="text-link" data-action="set-track-and-library" data-track="${track}">Lihat materi ↗</button></div></section>`;
      }).join('')}</div>${mobileNav()}`;
  }
  function renderLibrary() {
    const filtered = Catalog.filter(l => (!libraryQuery || `${l.title} ${l.unit} ${l.description}`.toLowerCase().includes(libraryQuery.toLowerCase())) && (libraryTrack==='all'||l.track===libraryTrack) && (libraryStatus==='all'||(libraryStatus==='completed'?isCompleted(l.id):libraryStatus==='available'?isUnlocked(l)&&!isCompleted(l.id):!isUnlocked(l))));
    content.innerHTML = `<div class="page-heading"><div><div class="eyebrow">MATERI TERSTRUKTUR</div><h1>Materi & latihan</h1><p>Setiap pelajaran berisi konsep, contoh normal, modifikasi, dan soal bergaya TKA.</p></div></div>
      <div class="library-toolbar"><label class="search-box"><span aria-hidden="true">⌕</span><input id="library-search" type="search" placeholder="Cari materi atau topik..." value="${esc(libraryQuery)}" aria-label="Cari materi"></label><select id="library-track" class="filter-select" aria-label="Filter jalur"><option value="all" ${libraryTrack==='all'?'selected':''}>Semua jalur</option><option value="wajib" ${libraryTrack==='wajib'?'selected':''}>Matematika Wajib</option><option value="lanjut" ${libraryTrack==='lanjut'?'selected':''}>Tingkat Lanjut</option></select><select id="library-status" class="filter-select" aria-label="Filter status"><option value="all" ${libraryStatus==='all'?'selected':''}>Semua status</option><option value="available" ${libraryStatus==='available'?'selected':''}>Bisa dipelajari</option><option value="completed" ${libraryStatus==='completed'?'selected':''}>Selesai</option><option value="locked" ${libraryStatus==='locked'?'selected':''}>Terkunci</option></select></div>
      <div class="section-head"><div><h2>${filtered.length} pelajaran</h2><p>Gunakan filter untuk menemukan jalur yang ingin kamu pelajari.</p></div></div>
      ${filtered.length?`<div class="lesson-grid">${filtered.map(renderLessonCard).join('')}</div>`:`<div class="empty-state"><strong>Materi tidak ditemukan</strong>Coba kata kunci atau filter yang berbeda.</div>`}${mobileNav()}`;
  }
  function renderLessonCard(l) {
    const status=lessonStatus(l);
    return `<article class="lesson-card ${status==='locked'?'locked':''}"><div class="lesson-card-top">${trackBadge(l.track)}<span class="level-tag">LEVEL ${String(l.order).padStart(2,'0')}</span></div><h3>${esc(l.title)}</h3><p>${esc(l.description)}</p><div class="lesson-card-meta"><span>◷ ${l.duration} menit</span><span>▤ ${l.questions.length} soal</span><span>${esc(l.difficulty)}</span></div><div class="lesson-card-footer"><span class="mini-status ${status==='completed'?'done':status==='locked'?'lock':''}">${status==='completed'?'✓ Selesai':status==='locked'?'⌑ Terkunci':'● Tersedia'}</span><button class="button ${status==='locked'?'button-quiet':'button-outline'}" data-action="open-lesson" data-lesson="${l.id}" ${status==='locked'?'disabled':''}>${status==='completed'?'Ulangi materi':status==='locked'?'Terkunci':'Pelajari →'}</button></div></article>`;
  }
  function renderLesson() {
    const lesson = getLesson(currentLessonId);
    if (!lesson) { page='library'; renderLibrary(); return; }
    if (!isUnlocked(lesson)) { page='path'; renderPath(); showToast('Selesaikan level sebelumnya untuk membuka materi ini.'); return; }
    content.innerHTML = `<div class="page-heading"><div><div class="eyebrow">RUANG BELAJAR</div><h1>Pelajari konsepnya</h1><p>Luangkan waktu untuk memahami ide sebelum memulai latihan.</p></div></div>
      <div class="lesson-layout"><article class="section-card lesson-article"><button class="back-link" data-action="back-to-path">← Kembali ke peta level</button><div class="lesson-title-row"><div class="track-symbol ${lesson.track}">${trackSymbol(lesson.track)}</div><div><div>${trackBadge(lesson.track)} <span class="level-tag">LEVEL ${String(lesson.order).padStart(2,'0')}</span></div><h1>${esc(lesson.title)}</h1><div class="muted tiny">${esc(lesson.unit)} · ${lesson.duration} menit · ${esc(lesson.difficulty)}</div></div></div><p class="lesson-intro">${esc(lesson.description)}</p>
      <div class="lesson-section"><h2>Tujuan pembelajaran</h2><ul class="objective-list">${lesson.objectives.map(o=>`<li><span class="check-mark">✓</span><span>${esc(o)}</span></li>`).join('')}</ul></div>
      ${lesson.concepts.map((c,i)=>`<section class="lesson-section"><h2>${esc(c.heading)}</h2><p>${esc(c.body)}</p>${c.formula?`<div class="formula-box">${esc(c.formula)}</div>`:''}</section>`).join('')}
      <div class="lesson-section"><h2>Contoh soal dan penyelesaian</h2><p>Amati bagaimana konsep digunakan pada soal dengan tingkat kesulitan berbeda.</p>${lesson.examples.map(ex=>`<div class="example-box"><span class="example-label">${esc(ex.label)}</span><h3>${esc(ex.title)}</h3><p>${esc(ex.question)}</p><ol class="solution-steps">${ex.solution.map(s=>`<li>${esc(s)}</li>`).join('')}</ol></div>`).join('')}</div>
      <div class="lesson-section"><h2>Siap menguji pemahaman?</h2><p>Latihan berisi ${lesson.questions.length} pertanyaan pilihan ganda. Ambang kelulusan versi awal adalah ${Core.PASS_THRESHOLD}%.</p><button class="button button-primary" data-action="start-quiz" data-lesson="${lesson.id}">Mulai latihan &nbsp; →</button></div></article>
      <aside class="lesson-side"><section class="section-card lesson-side-card"><h3>Ringkasan level</h3><div class="info-pair"><span>Status</span><strong>${isCompleted(lesson.id)?'Sudah selesai':'Belum selesai'}</strong></div><div class="info-pair"><span>Jumlah soal</span><strong>${lesson.questions.length} soal</strong></div><div class="info-pair"><span>Target lulus</span><strong>${Core.PASS_THRESHOLD}%</strong></div><div class="info-pair"><span>XP level</span><strong>hingga ${lesson.questions.length*2+10} XP</strong></div><button class="button button-primary" data-action="start-quiz" data-lesson="${lesson.id}">Kerjakan soal ↗</button></section><section class="section-card lesson-side-card"><h3>Urutan belajar</h3><ul class="objective-list"><li><span class="check-mark">1</span><span>Pahami konsep dan notasi.</span></li><li><span class="check-mark">2</span><span>Pelajari contoh penyelesaian.</span></li><li><span class="check-mark">3</span><span>Kerjakan soal tanpa melihat kunci.</span></li><li><span class="check-mark">4</span><span>Baca pembahasan setelah menjawab.</span></li></ul></section><section class="tip-card"><div class="tip-icon">i</div><div><strong>Catatan sumber</strong><p>Materi latihan ditulis ulang dan disusun sebagai contoh edukatif. Rujukan resmi ada di bagian sumber.</p></div></section></aside></div>${mobileNav()}`;
  }
  function renderQuiz() {
    if (!quizSession) { page='dashboard'; renderDashboard(); return; }
    const lesson=getLesson(quizSession.lessonId);
    if(!lesson){page='dashboard';renderDashboard();return;}
    const q=lesson.questions[quizSession.index];
    const selected=quizSession.selected;
    const answered=quizSession.submitted;
    const correct=answered && selected===q.answer;
    content.innerHTML = `<div class="quiz-wrap"><div class="quiz-top"><button class="back-link" data-action="quit-quiz">← Keluar dari latihan</button><div class="quiz-progress-area"><div class="quiz-progress-caption"><span>${esc(lesson.title)}</span><span>${quizSession.index+1} dari ${lesson.questions.length}</span></div><div class="progress-track"><div class="progress-fill" style="width:${(quizSession.index+1)/lesson.questions.length*100}%"></div></div></div></div>
      <section class="quiz-card"><div class="eyebrow">${esc(q.kind)} · ${trackLabel(lesson.track)}</div><h1>Periksa pemahamanmu</h1><div class="quiz-description">Pilih satu jawaban terbaik. Pembahasan akan muncul setelah kamu memeriksa jawaban.</div><div class="question-text">${esc(q.prompt)}</div><div class="option-list" role="group" aria-label="Opsi jawaban">${q.choices.map((choice,i)=>{let cls='';if(answered&&i===q.answer)cls=' correct';else if(answered&&i===selected&&i!==q.answer)cls=' incorrect';else if(!answered&&selected===i)cls=' selected';return `<button class="option-button${cls}" data-action="select-answer" data-index="${i}" ${answered?'disabled':''} aria-pressed="${selected===i?'true':'false'}"><span class="option-letter">${'ABCDE'[i]}</span><span class="option-text">${esc(choice)}</span></button>`}).join('')}</div>
      ${answered?`<div class="answer-feedback ${correct?'good':'bad'}" role="status"><strong>${correct?'Tepat! Jawabanmu benar.':'Belum tepat. Yuk pahami caranya.'}</strong>${esc(q.explanation)}</div>`:''}
      <div class="quiz-footer"><span class="muted">${answered?'Jawaban telah dikunci.':'Pilih A, B, C, D, atau E.'}</span>${answered?`<button class="button button-primary" data-action="next-question">${quizSession.index===lesson.questions.length-1?'Lihat hasil →':'Soal berikutnya →'}</button>`:`<button class="button button-primary" data-action="check-answer" ${selected===null?'disabled':''}>Periksa jawaban</button>`}</div></section><p class="accessibility-note">Setiap soal hanya dinilai setelah kamu menekan “Periksa jawaban”. Kunci jawaban tidak ditampilkan sebelum itu.</p></div>${mobileNav()}`;
  }
  function renderResult() {
    if (!lastResult) { page='dashboard';renderDashboard();return; }
    const lesson=getLesson(lastResult.lessonId);
    if(!lesson){page='dashboard';renderDashboard();return;}
    const passed=lastResult.passed;
    content.innerHTML = `<section class="result-card"><div class="result-icon ${passed?'':'retry'}">${passed?'✓':'↻'}</div><div class="eyebrow">HASIL EVALUASI</div><h1>${passed?'Level berhasil diselesaikan':'Hampir sampai — coba lagi'}</h1><div class="result-score">${lastResult.score}%</div><p>${passed?`Kamu memenuhi ambang kelulusan untuk ${esc(lesson.title)}. Pemahamanmu tercatat dan level berikutnya di jalur ini kini dapat dibuka.`:`Kamu membutuhkan minimal ${Core.PASS_THRESHOLD}% untuk lulus. Baca ulang pembahasan, lalu ulangi latihan untuk memperkuat konsep.`}</p><div class="result-metrics"><div class="result-metric"><strong>${lastResult.correct}/${lastResult.total}</strong><span>Jawaban benar</span></div><div class="result-metric"><strong>+${lastResult.xpAdded}</strong><span>XP diperoleh</span></div><div class="result-metric"><strong>${passed?'Lulus':'Ulangi'}</strong><span>Status level</span></div></div><div class="result-actions"><button class="button button-primary" data-action="result-primary" data-lesson="${lesson.id}">${passed?'Lanjut ke level berikutnya':'Ulangi latihan'} →</button><button class="button button-outline" data-action="review-lesson" data-lesson="${lesson.id}">Baca materi lagi</button><button class="button button-quiet" data-action="navigate" data-page="path">Kembali ke peta</button></div></section>${mobileNav()}`;
  }
  function renderProgress() {
    const done=state.completedLessons.length;
    const avg=state.attempts.length?Math.round(state.attempts.reduce((s,a)=>s+a.score,0)/state.attempts.length):0;
    const totalPct=Math.round(done/Catalog.length*100);
    const attempts=[...state.attempts].slice(-8).reverse();
    content.innerHTML = `<div class="page-heading"><div><div class="eyebrow">LAPORAN PERKEMBANGAN</div><h1>Progres belajarmu</h1><p>Lihat hasil latihan dan bagian kurikulum yang sudah kamu tuntaskan.</p></div><button class="button button-outline" data-action="navigate" data-page="library">Latihan lagi ↗</button></div>
      <div class="progress-grid"><div class="left-stack"><section class="section-card progress-overview"><div class="progress-overview-top"><div class="donut" style="--progress-angle:${totalPct*3.6}deg"><div class="donut-inner"><strong>${totalPct}%</strong><span>kurikulum</span></div></div><div><h2>${done===Catalog.length?'Luar biasa! Semua level selesai.':done?'Progres yang baik.':'Perjalanan baru dimulai.'}</h2><p>Kamu telah menyelesaikan ${done} dari ${Catalog.length} level yang tersedia pada versi awal. Teruskan latihan untuk membangun pemahaman yang kuat.</p></div></div><div class="course-progress-row" style="margin-top:18px"><div class="course-progress-title"><span>Matematika Wajib</span><span>${progressFor('wajib')}%</span></div><div class="progress-track"><div class="progress-fill" style="width:${progressFor('wajib')}%"></div></div></div><div class="course-progress-row"><div class="course-progress-title"><span>Matematika Tingkat Lanjut</span><span>${progressFor('lanjut')}%</span></div><div class="progress-track"><div class="progress-fill green-fill" style="width:${progressFor('lanjut')}%"></div></div></div></section>
      <section class="section-card card-pad"><div class="section-head"><div><h2>Riwayat latihan</h2><p>Ringkasan beberapa percobaan terakhir.</p></div><span class="pill-label">${state.attempts.length} sesi</span></div>${attempts.length?`<div class="history-list">${attempts.map(renderHistoryItem).join('')}</div>`:`<div class="empty-state"><strong>Belum ada latihan</strong>Mulai satu level untuk melihat hasil dan riwayat di sini.</div>`}</section></div>
      <div class="right-stack"><section class="section-card side-summary"><div class="side-summary-head"><h2>Ringkasan performa</h2><span class="pill-label">LIFETIME</span></div><div class="small-metrics" style="margin-top:18px"><div class="small-metric"><strong>${state.xp}</strong><span>Total XP</span></div><div class="small-metric"><strong>${avg}%</strong><span>Rata-rata skor</span></div></div><div class="daily-goal"><div class="section-head"><h2>Target latihan hari ini</h2><span>${Math.min(questionGoalProgress(),state.dailyGoal)}/${state.dailyGoal}</span></div><div class="progress-track"><div class="progress-fill green-fill" style="width:${Math.min(100,questionGoalProgress()/state.dailyGoal*100)}%"></div></div></div><div class="info-pair" style="margin-top:16px"><span>Jumlah percobaan</span><strong>${state.attempts.length}</strong></div><div class="info-pair"><span>Jawaban tercatat</span><strong>${currentQuestionCount()}</strong></div><div class="info-pair"><span>Level selesai</span><strong>${done}/${Catalog.length}</strong></div></section><section class="tip-card"><div class="tip-icon">↗</div><div><strong>Belajar dari kesalahan</strong><p>Gunakan pembahasan setelah setiap soal. Fokus pada pola kesalahan, bukan hanya mengejar nilai.</p></div></section></div></div>${mobileNav()}`;
  }
  function renderHistoryItem(a) {
    const lesson=getLesson(a.lessonId);
    if(!lesson)return '';
    return `<div class="history-item"><div class="history-dot">${a.passed?'✓':'↻'}</div><div style="flex:1;min-width:0"><strong>${esc(lesson.title)}</strong><span>${esc(trackLabel(lesson.track))} · ${esc(String(a.date||''))} · ${a.correct||0}/${a.total||lesson.questions.length} benar</span></div><span class="mini-status ${a.passed?'done':''}">${Math.round(a.score)}%</span></div>`;
  }
  function renderProfile() {
    content.innerHTML = `<div class="page-heading"><div><div class="eyebrow">PREFERENSI & IDENTITAS</div><h1>Profil siswa</h1><p>Sesuaikan profil belajar dan target latihanmu.</p></div></div>
      <div class="profile-layout"><section class="section-card profile-card"><div class="profile-hero"><div class="big-avatar">${esc(initials(state.profile.name))}</div><div><h2>${esc(state.profile.name)}</h2><p>${esc(state.profile.grade)} · ${esc(state.profile.goal)}</p><span class="track-badge wajib" style="margin-top:9px">PROFIL PERANGKAT</span></div></div><form id="profile-form"><div class="form-field"><label for="profile-name">Nama tampilan</label><input id="profile-name" name="profile-name" type="text" maxlength="32" required value="${esc(state.profile.name)}" autocomplete="nickname"><span class="form-help">Nama ini ditampilkan di dashboard. Jangan gunakan informasi pribadi yang sensitif.</span></div><div class="form-field"><label for="profile-grade">Jenjang</label><select id="profile-grade" name="profile-grade"><option ${state.profile.grade==='Kelas X'?'selected':''}>Kelas X</option><option ${state.profile.grade==='Kelas XI'?'selected':''}>Kelas XI</option><option ${state.profile.grade==='Kelas XII'?'selected':''}>Kelas XII</option><option ${state.profile.grade==='Lainnya'?'selected':''}>Lainnya</option></select></div><div class="form-field"><label for="profile-goal">Tujuan belajar</label><select id="profile-goal" name="profile-goal"><option ${state.profile.goal==='Fondasi matematika'?'selected':''}>Fondasi matematika</option><option ${state.profile.goal==='TKA SMA'?'selected':''}>TKA SMA</option><option ${state.profile.goal==='Pendalaman materi'?'selected':''}>Pendalaman materi</option></select></div><div class="form-field"><label for="daily-goal">Target soal per hari</label><select id="daily-goal" name="daily-goal"><option value="5" ${state.dailyGoal===5?'selected':''}>5 soal — santai</option><option value="10" ${state.dailyGoal===10?'selected':''}>10 soal — rutin</option><option value="15" ${state.dailyGoal===15?'selected':''}>15 soal — intensif</option><option value="20" ${state.dailyGoal===20?'selected':''}>20 soal — tantangan</option></select></div><button class="button button-primary" type="submit">Simpan profil</button></form></section>
      <div class="right-stack"><section class="section-card profile-card"><div class="section-head"><div><h2>Penyimpanan & privasi</h2><p>Informasi penting tentang versi ini.</p></div></div><div class="setting-row"><div><strong>Penyimpanan lokal</strong><p>Profil, XP, percobaan, dan progres tersimpan di browser/perangkat ini. Belum tersinkron antargawai atau memakai login cloud.</p></div></div><div class="setting-row"><div><strong>Keamanan data</strong><p>Jangan memasukkan kata sandi penting, data sekolah yang sensitif, atau informasi pribadi yang tidak diperlukan.</p></div></div><div class="setting-row"><div><strong>Ekspor progres</strong><p>Simpan salinan progres sebagai file JSON untuk arsip pribadi.</p></div><button class="button button-outline" data-action="export-state">Ekspor</button></div><div class="setting-row"><div><strong>Impor progres</strong><p>Pulihkan file progres yang sebelumnya diekspor dari MathLevel.</p></div><button class="button button-outline" data-action="import-state">Impor</button><input id="import-file" type="file" accept="application/json,.json" class="hidden" aria-label="Pilih file progres"></div><div class="setting-row"><div><strong>Reset progres</strong><p>Menghapus progres lokal di perangkat ini dan memulai ulang. Tindakan tidak dapat dibatalkan.</p></div><button class="danger-button" data-action="reset-state">Reset data</button></div></section>
      <section class="section-card profile-card"><div class="section-head"><div><h2>Referensi pembelajaran</h2><p>Rujukan resmi untuk pengembangan kurikulum.</p></div></div><div class="source-list"><div class="source-item"><strong>TKA Matematika Wajib SMA</strong><p>Elemen dan matriks asesmen resmi. Materi website perlu dipetakan ke submateri aktual pada dokumen.</p><a href="https://pusmendik.kemendikdasmen.go.id/tka/tka/view/mata-pelajaran-wajib/sma/" target="_blank" rel="noopener noreferrer">Buka sumber resmi ↗</a></div><div class="source-item"><strong>TKA Matematika Tingkat Lanjut SMA</strong><p>Referensi aljabar, geometri dan pengukuran, serta kalkulus.</p><a href="https://pusmendik.kemendikdasmen.go.id/tka/tka/view/mata-pelajaran-pilihan/sma/matematika-tingkat-lanjut" target="_blank" rel="noopener noreferrer">Buka sumber resmi ↗</a></div><div class="source-item"><strong>Buku teks Kemendikdasmen</strong><p>Gunakan buku siswa dan buku panduan guru yang relevan. Materi starter dibuat sebagai penjelasan dan contoh orisinal, bukan salinan buku.</p><a href="https://buku.kemendikdasmen.go.id/" target="_blank" rel="noopener noreferrer">Cari buku resmi ↗</a></div></div></section></div></div>${mobileNav()}`;
  }
  function mobileNav() {
    return `<nav class="mobile-nav" aria-label="Navigasi mobile"><button data-action="navigate" data-page="dashboard"><span>⌂</span>Beranda</button><button data-action="navigate" data-page="path"><span>⌁</span>Level</button><button data-action="navigate" data-page="library"><span>▤</span>Materi</button><button data-action="navigate" data-page="progress"><span>▥</span>Progres</button><button data-action="navigate" data-page="profile"><span>◎</span>Profil</button></nav>`;
  }
  function startQuiz(lessonId) {
    const lesson=getLesson(lessonId);
    if(!lesson){showToast('Materi tidak ditemukan.','error');return;}
    if(!isUnlocked(lesson)){showToast('Selesaikan level sebelumnya untuk membuka materi ini.');return;}
    currentLessonId=lessonId;
    quizSession={lessonId,index:0,selected:null,submitted:false,answers:[],xpAdded:0};
    page='quiz';
    render();
  }
  function submitCurrentAnswer() {
    if(!quizSession||quizSession.submitted)return;
    if(quizSession.selected===null){showToast('Pilih salah satu jawaban terlebih dahulu.');return;}
    const lesson=getLesson(quizSession.lessonId); const question=lesson.questions[quizSession.index]; const index=quizSession.selected;
    const answer={questionId:question.id,selectedIndex:index};
    quizSession.answers=quizSession.answers.filter(a=>a.questionId!==question.id).concat(answer);
    quizSession.submitted=true;
    const date=todayKey();
    const oldXp=state.xp;
    if(state.questionGoalDate!==date){state.questionGoalDate=date;state.todayQuestions=[];}
    if(!Array.isArray(state.todayQuestions))state.todayQuestions=[];
    if(!state.todayQuestions.includes(question.id))state.todayQuestions.push(question.id);
    Core.markStudyDay(state,date);
    if(index===question.answer){const reward=Core.uniqueXp(state,`question:${question.id}`,2);quizSession.xpAdded+=reward.added;}
    saveState();
    render();
    if(index===question.answer) showToast(`Jawaban benar${state.xp>oldXp?' · +2 XP':''}.`,'success');
  }
  function nextQuestion() {
    if(!quizSession||!quizSession.submitted)return;
    const lesson=getLesson(quizSession.lessonId);
    if(quizSession.index<lesson.questions.length-1){quizSession.index++;quizSession.selected=null;quizSession.submitted=false;render();return;}
    finishQuiz();
  }
  function finishQuiz() {
    const lesson=getLesson(quizSession.lessonId);
    const score=Core.calculateScore(quizSession.answers,lesson.questions);
    const correct=quizSession.answers.filter(a=>{const q=lesson.questions.find(qq=>qq.id===a.questionId);return q&&a.selectedIndex===q.answer;}).length;
    const passed=Core.isPassing(score,Core.PASS_THRESHOLD);
    const beforeXp=state.xp;
    if(passed&&!state.completedLessons.includes(lesson.id)){
      state.completedLessons.push(lesson.id);
      const reward=Core.uniqueXp(state,`level:${lesson.id}`,10);
      quizSession.xpAdded+=reward.added;
      unlockAchievements();
    }
    state.attempts.push({lessonId:lesson.id,score,passed,correct,total:lesson.questions.length,date:todayKey(),createdAt:new Date().toISOString()});
    state.attempts=state.attempts.slice(-100);
    saveState();
    lastResult={lessonId:lesson.id,score,passed,correct,total:lesson.questions.length,xpAdded:state.xp-beforeXp};
    quizSession=null;page='result';render();
  }
  function unlockAchievements() {
    const achievements=[];
    if(state.completedLessons.length>=1)achievements.push('first-level');
    if(state.completedLessons.length>=5)achievements.push('five-levels');
    if(progressFor('wajib')===100)achievements.push('wajib-master');
    if(progressFor('lanjut')===100)achievements.push('lanjut-master');
    state.unlockedAchievements=[...new Set([...(state.unlockedAchievements||[]),...achievements])];
  }
  function playNext() {
    const next=getSuggestedLesson();
    if(!next){showToast('Belum ada materi pada jalur ini.');return;}
    if(!isUnlocked(next)){page='path';render();showToast('Selesaikan level sebelumnya untuk membuka materi selanjutnya.');return;}
    currentLessonId=next.id;page='lesson';render();
  }
  function exportState() {
    try {
      const payload={app:'MathLevel Academy',schemaVersion:1,exportedAt:new Date().toISOString(),state};
      const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
      const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`mathlevel-progres-${todayKey()}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('File progres berhasil disiapkan.','success');
    }catch(e){showToast('Ekspor gagal pada browser ini.','error');}
  }
  function importState(file) {
    if(!file)return;
    const reader=new FileReader();
    reader.onload=()=>{
      try{
        const parsed=JSON.parse(String(reader.result||''));const raw=parsed&&parsed.state?parsed.state:parsed;const candidate=Core.sanitizeState(raw,lessonIds);
        if(!parsed||typeof parsed!=='object'||!candidate.profile)throw new Error('File tidak valid');
        state=candidate;saveState();page='dashboard';quizSession=null;render();showToast('Progres berhasil diimpor.','success');
      }catch(e){showToast('File tidak sesuai format progres MathLevel.','error');}
    };
    reader.onerror=()=>showToast('File tidak dapat dibaca.','error');reader.readAsText(file);
  }
  document.addEventListener('click', event => {
    const target=event.target.closest('[data-action]');
    if(!target)return;
    const action=target.dataset.action;
    if(action==='navigate'){page=target.dataset.page||'dashboard';quizSession=null;render();return;}
    if(action==='toggle-sidebar'){document.getElementById('sidebar').classList.toggle('open');return;}
    if(action==='set-track'){selectedTrack=target.dataset.track==='lanjut'?'lanjut':'wajib';render();return;}
    if(action==='set-track-and-library'){libraryTrack=target.dataset.track||'all';page='library';render();return;}
    if(action==='play-next'){playNext();return;}
    if(action==='open-lesson'){const id=target.dataset.lesson;const lesson=getLesson(id);if(!lesson)return;if(!isUnlocked(lesson)){showToast('Level ini terkunci. Selesaikan level sebelumnya terlebih dahulu.');return;}currentLessonId=id;page='lesson';render();return;}
    if(action==='start-quiz'){startQuiz(target.dataset.lesson||currentLessonId);return;}
    if(action==='select-answer'){if(!quizSession||quizSession.submitted)return;const index=Number(target.dataset.index);if(!Number.isInteger(index)||index<0||index>4)return;quizSession.selected=index;render();return;}
    if(action==='check-answer'){submitCurrentAnswer();return;}
    if(action==='next-question'){nextQuestion();return;}
    if(action==='quit-quiz'){if(window.confirm('Keluar dari latihan ini? Jawaban pada sesi yang belum selesai tidak akan dinilai.')){quizSession=null;page='lesson';render();}return;}
    if(action==='back-to-path'){page='path';render();return;}
    if(action==='result-primary'){const lesson=getLesson(target.dataset.lesson);if(!lesson)return;if(lastResult&&lastResult.passed){const next=Catalog.filter(l=>l.track===lesson.track).sort((a,b)=>a.order-b.order).find(l=>l.order>lesson.order&&!isCompleted(l.id)&&isUnlocked(l));if(next){currentLessonId=next.id;page='lesson';render();return;}page='path';render();showToast('Jalur ini selesai untuk semua level yang tersedia.','success');return;}startQuiz(lesson.id);return;}
    if(action==='review-lesson'){currentLessonId=target.dataset.lesson;page='lesson';render();return;}
    if(action==='export-state'){exportState();return;}
    if(action==='import-state'){const input=document.getElementById('import-file');if(input)input.click();return;}
    if(action==='reset-state'){if(window.confirm('Reset akan menghapus XP, riwayat, dan level selesai pada perangkat ini. Lanjutkan?')){try{localStorage.removeItem(Core.STORAGE_KEY);}catch(e){}state=Core.getDefaultState();selectedTrack='wajib';quizSession=null;lastResult=null;page='dashboard';saveState();render();showToast('Progres lokal telah direset.','success');}return;}
  });
  document.addEventListener('submit', event => {
    if(event.target.id!=='profile-form')return;
    event.preventDefault();
    const name=Core.normalizeName(document.getElementById('profile-name').value);
    if(!name){showToast('Nama tampilan tidak boleh kosong.','error');return;}
    state.profile.name=name;
    state.profile.grade=document.getElementById('profile-grade').value;
    state.profile.goal=document.getElementById('profile-goal').value;
    state.dailyGoal=Number(document.getElementById('daily-goal').value)||5;
    saveState();render();showToast('Profil berhasil disimpan.','success');
  });
  document.addEventListener('input', event => {
    if(event.target.id==='library-search'){
      const pos=event.target.selectionStart;
      libraryQuery=event.target.value;
      const scroll=content.scrollTop;
      renderLibrary();content.scrollTop=scroll;
      const newInput=document.getElementById('library-search');if(newInput){newInput.focus();try{newInput.setSelectionRange(pos,pos);}catch(e){}}
    }
  });
  document.addEventListener('change', event => {
    if(event.target.id==='library-track'){libraryTrack=event.target.value;renderLibrary();}
    if(event.target.id==='library-status'){libraryStatus=event.target.value;renderLibrary();}
    if(event.target.id==='import-file')importState(event.target.files&&event.target.files[0]);
  });
  document.addEventListener('keydown', event => {
    if(event.key==='Escape'&&document.getElementById('sidebar').classList.contains('open'))document.getElementById('sidebar').classList.remove('open');
  });
  function checkCatalog() {
    const issues=[];
    for(const lesson of Catalog){
      if(!lesson.id||!['wajib','lanjut'].includes(lesson.track))issues.push(`Metadata tidak valid: ${lesson.id}`);
      if(!Array.isArray(lesson.questions)||lesson.questions.length<1)issues.push(`Tidak ada soal: ${lesson.id}`);
      for(const q of lesson.questions){if(!Array.isArray(q.choices)||q.choices.length!==5)issues.push(`Opsi bukan A-E: ${lesson.id}/${q.id}`);if(!Number.isInteger(q.answer)||q.answer<0||q.answer>4)issues.push(`Kunci tidak valid: ${lesson.id}/${q.id}`);if(!q.explanation)issues.push(`Pembahasan kosong: ${lesson.id}/${q.id}`);}
    }
    if(issues.length){console.error('[MathLevel] Validasi katalog gagal',issues);showToast('Sebagian konten perlu diperiksa. Lihat konsol pengembang.','error');}
  }
  checkCatalog();
  render();
})();
