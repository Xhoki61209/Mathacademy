# MathLevel Academy

Website pembelajaran matematika SMA dengan jalur Matematika Wajib dan Matematika Tingkat Lanjut, materi, contoh soal bertingkat, kuis A–E, umpan balik, progres level, profil lokal, XP, streak, ekspor dan impor progres.

## Isi proyek

- `index.html` — shell dan struktur aplikasi.
- `styles.css` — desain responsif tanpa framework CSS eksternal.
- `core.js` — fungsi logika murni untuk status, skor, progres, XP, profil, dan streak.
- `catalog.js` — 13 modul awal, 65 soal dan pembahasannya.
- `app.js` — rendering dan interaksi website.
- `tests/run-qa.cjs` — pengujian logika dan integritas katalog.
- `tests/content-audit.cjs` — pemeriksaan jawaban berdasarkan audit manual pada 65 kunci.
- `tests/simulate-users.cjs` — simulasi deterministik 100 profil bot dan 2.000 kasus sanitasi.
- `tests/static-audit.cjs` — cek referensi aset, aksi UI, ID, dan struktur CSS.
- `.github/workflows/pages.yml` — pipeline validasi dan deployment GitHub Pages.
- `_headers` — header keamanan untuk hosting yang mendukung file konfigurasi header seperti Cloudflare Pages.

## Jalankan lokal

Perlu Node.js 18+ untuk tes. Website sendiri tidak memerlukan proses build atau library runtime eksternal.

1. Ekstrak ZIP.
2. Jalankan server statis dari folder proyek, misalnya `python -m http.server 8000`.
3. Buka `http://localhost:8000`.

Membuka file langsung melalui `file://` mungkin membatasi penyimpanan lokal di beberapa browser; gunakan server statis untuk pengujian yang representatif.

## Pengujian

```bash
node --check app.js
node --check core.js
node --check catalog.js
node tests/run-qa.cjs
node tests/content-audit.cjs
node tests/simulate-users.cjs
node tests/static-audit.cjs
```

Tes menguji integritas ID dan soal, opsi A–E, aturan skor, threshold, pembukaan level berurutan, batas progres, sanitasi data, penghindaran XP ganda, dan perhitungan streak. Tes ini bukan pengganti pengujian browser pada semua perangkat atau pemeriksaan ahli matematika terhadap seluruh pengembangan konten.

## Batasan versi awal

- Profil dan progres disimpan di `localStorage` browser/perangkat yang sedang digunakan. Tidak ada pendaftaran akun cloud, sinkronisasi antargawai, atau database server pada paket statis ini.
- Pembukaan level dan penilaian berjalan di sisi klien. Karena itu, versi ini adalah MVP edukasi yang cocok untuk penggunaan pribadi dan demonstrasi, bukan sistem ujian berisiko tinggi dengan anti-kecurangan atau data terpusat.
- Bank soal awal berisi 65 soal lintas 13 level. Konten ini merupakan starter, bukan cakupan lengkap seluruh kisi-kisi TKA.
- Soal latihan disusun secara orisinal dan berorientasi pada elemen asesmen yang relevan; bukan kumpulan soal resmi atau jaminan prediksi soal ujian.
- Ambang kelulusan 80% adalah keputusan produk yang dapat diubah, bukan ketentuan kelulusan resmi TKA.

## Deployment gratis

Lihat `DEPLOYMENT.md`. Workflow GitHub Pages telah disediakan untuk menguji JavaScript/katalog dan menerbitkan situs setelah repository dihubungkan serta Pages diaktifkan. Deployment tidak dilakukan otomatis hanya dengan mengunduh ZIP.
