#!/usr/bin/env sh
set -eu
node --check app.js
node --check core.js
node --check catalog.js
node tests/run-qa.cjs
node tests/content-audit.cjs
node tests/simulate-users.cjs
node tests/static-audit.cjs
