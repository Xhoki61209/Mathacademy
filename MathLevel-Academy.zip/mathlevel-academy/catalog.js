/* Curated starter curriculum. Topics are mapped to official TKA element areas; verify the live official matrix before expanding the course. */
(function (root, factory) {
  const catalog = factory();
  if (typeof module === 'object' && module.exports) module.exports = catalog;
  if (root) root.MathLevelCatalog = catalog;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const lessons = [

    {
      id:'w-bilangan',track:'wajib',order:1,unit:'Bilangan',title:'Bilangan & Operasi',duration:12,difficulty:'Fondasi',
      description:'Bangun fondasi melalui operasi bilangan bulat, pecahan, pangkat, dan perbandingan dalam masalah sederhana.',
      objectives:['Melakukan operasi bilangan bulat','Menghitung penjumlahan pecahan','Menggunakan sifat pangkat dan perbandingan'],
      concepts:[
        {heading:'1. Operasi bilangan bulat',body:'Perhatikan tanda positif dan negatif. Menjumlahkan bilangan negatif berarti bergerak ke kiri pada garis bilangan.',formula:'−7 + 12 = 5'},
        {heading:'2. Operasi pecahan',body:'Untuk menjumlahkan pecahan dengan penyebut berbeda, samakan penyebut terlebih dahulu lalu jumlahkan pembilangnya.',formula:'3/4 + 1/6 = 9/12 + 2/12 = 11/12'},
        {heading:'3. Sifat pangkat dan perbandingan',body:'Saat mengalikan pangkat dengan basis sama, jumlahkan pangkatnya. Untuk perbandingan, jumlahkan bagian rasio sebelum membagi jumlah total.',formula:'aᵐ × aⁿ = aᵐ⁺ⁿ  ·  a⁻¹ = 1/a'}
      ],
      examples:[
        {label:'Normal',title:'Hitung −7 + 12',question:'Bilangan positif 12 lebih besar daripada nilai mutlak −7.',solution:['Mulai dari −7, kemudian bergerak 12 satuan ke kanan.','Hasilnya 5.']},
        {label:'Modifikasi',title:'Hitung 3/4 + 1/6',question:'Samakan penyebut menjadi 12.',solution:['3/4 = 9/12 dan 1/6 = 2/12.','Jumlahnya 11/12.']},
        {label:'Bergaya TKA',title:'Perbandingan 2 : 3 dari total 25',question:'Jumlah bagian rasio adalah 5 bagian.',solution:['Satu bagian = 25/5 = 5.','Kelompok pertama = 2 × 5 = 10.']}
      ],
      questions:[
        {id:'wb1',kind:'Normal',prompt:'Nilai dari −7 + 12 adalah …',choices:['−19','−5','5','12','19'],answer:2,explanation:'Dari −7 bergerak 12 satuan ke kanan pada garis bilangan, sehingga hasilnya 5.'},
        {id:'wb2',kind:'Normal',prompt:'Hasil dari 3/4 + 1/6 adalah …',choices:['5/10','10/12','11/12','3/10','1'],answer:2,explanation:'Samakan penyebut: 3/4 = 9/12 dan 1/6 = 2/12. Jumlahnya 11/12.'},
        {id:'wb3',kind:'Modifikasi',prompt:'Nilai 2³ × 2² adalah …',choices:['16','24','32','64','128'],answer:2,explanation:'Untuk basis yang sama, pangkat dijumlahkan: 2³ × 2² = 2⁵ = 32.'},
        {id:'wb4',kind:'Normal',prompt:'Nilai 5⁻¹ sama dengan …',choices:['−5','−1/5','1/25','1/5','5'],answer:3,explanation:'Pangkat −1 berarti kebalikan basis: 5⁻¹ = 1/5.'},
        {id:'wb5',kind:'TKA · Penerapan',prompt:'Dua kelompok memiliki perbandingan 2 : 3 dan jumlah anggota 25. Banyak anggota kelompok pertama adalah …',choices:['5','8','10','15','20'],answer:2,explanation:'Jumlah bagian = 2+3 = 5. Satu bagian berisi 25/5 = 5 anggota. Kelompok pertama = 2×5 = 10.'}
      ]
    },
    {
      id:'w-aljabar', track:'wajib', order:2, unit:'Aljabar', title:'Operasi & Bentuk Aljabar', duration:12, difficulty:'Fondasi',
      description:'Rapikan operasi aljabar, sifat distributif, dan pemfaktoran sebagai fondasi untuk persamaan yang lebih kompleks.',
      objectives:['Menggunakan sifat distributif dengan benar','Menyederhanakan bentuk aljabar','Menghubungkan bentuk aljabar dan faktorisasi'],
      concepts:[
        {heading:'1. Sifat distributif',body:'Perkalian di luar kurung harus dikalikan ke setiap suku di dalam kurung. Perhatikan tanda negatif karena tanda ikut dikalikan.',formula:'a(b + c) = ab + ac'},
        {heading:'2. Menggabungkan suku sejenis',body:'Suku sejenis memiliki variabel dan pangkat yang sama. Koefisiennya dapat dijumlahkan atau dikurangkan, sedangkan variabel dipertahankan.',formula:'3x + 2x − 4 = 5x − 4'},
        {heading:'3. Pemfaktoran',body:'Pemfaktoran menulis bentuk penjumlahan sebagai hasil kali faktor. Untuk bentuk kuadrat, cari pasangan faktor yang memenuhi koefisien tengah dan konstanta.',formula:'x² + (p + q)x + pq = (x + p)(x + q)'}
      ],
      examples:[
        {label:'Normal',title:'Sederhanakan 2(x + 5)',question:'Kalikan 2 ke setiap suku dalam kurung.',solution:['2(x + 5) = 2x + 10.','Jawaban: 2x + 10.']},
        {label:'Modifikasi',title:'Sederhanakan 3(2x − 4) + 5',question:'Ingat bahwa konstanta di luar kurung tetap dijumlahkan setelah distribusi.',solution:['3(2x − 4) + 5 = 6x − 12 + 5.','Gabungkan konstanta: −12 + 5 = −7.','Jawaban: 6x − 7.']},
        {label:'Bergaya TKA',title:'Faktorkan 4x² − 12x − 7',question:'Cari pasangan faktor yang menghasilkan 4x², konstanta −7, dan suku tengah −12x.',solution:['Coba (2x + 1)(2x − 7).','Perluas: 4x² − 14x + 2x − 7.','Gabungkan suku tengah: −14x + 2x = −12x.','Jadi 4x² − 12x − 7 = (2x + 1)(2x − 7).']}
      ],
      questions:[
        {id:'wa1',kind:'Normal',prompt:'Sederhanakan 3(2x − 4) + 5.',choices:['6x − 7','6x − 17','6x + 17','5x − 7','6x − 12'],answer:0,explanation:'Distribusikan 3: 6x − 12 + 5. Setelah konstanta digabung, hasilnya 6x − 7.'},
        {id:'wa2',kind:'Normal',prompt:'Hasil perkalian (x + 3)(x − 2) adalah …',choices:['x² + 5x − 6','x² + x − 6','x² − x + 6','x² − 6','x² + x + 6'],answer:1,explanation:'Kalikan setiap suku: x² − 2x + 3x − 6 = x² + x − 6.'},
        {id:'wa3',kind:'Modifikasi',prompt:'Bentuk faktor dari x² + 7x + 12 adalah …',choices:['(x + 3)(x + 4)','(x − 3)(x − 4)','(x + 2)(x + 6)','(x + 1)(x + 12)','(x − 2)(x − 6)'],answer:0,explanation:'Kita mencari dua bilangan yang jumlahnya 7 dan hasil kalinya 12, yaitu 3 dan 4.'},
        {id:'wa4',kind:'Modifikasi',prompt:'Sederhanakan 2a − 3(a − 4).',choices:['−a − 12','a + 12','−a + 12','5a − 12','−a + 4'],answer:2,explanation:'−3(a − 4) = −3a + 12, sehingga 2a − 3a + 12 = −a + 12.'},
        {id:'wa5',kind:'TKA · Penalaran',prompt:'Pemfaktoran yang benar untuk 4x² − 12x − 7 adalah …',choices:['(4x + 1)(x − 7)','(2x − 1)(2x + 7)','(2x − 1)(2x − 7)','(2x + 1)(2x − 7)','(4x − 7)(x + 1)'],answer:3,explanation:'(2x + 1)(2x − 7) = 4x² − 14x + 2x − 7 = 4x² − 12x − 7.'}
      ]
    },
    {
      id:'w-kuadrat',track:'wajib',order:3,unit:'Aljabar',title:'Persamaan Kuadrat',duration:15,difficulty:'Fondasi → Menengah',
      description:'Pahami akar, diskriminan, jumlah dan hasil kali akar, serta hubungan bentuk faktor dengan penyelesaian.',
      objectives:['Mengenali koefisien a, b, dan c','Menghubungkan akar dengan jumlah dan hasil kali','Menafsirkan diskriminan persamaan kuadrat'],
      concepts:[
        {heading:'1. Bentuk umum',body:'Persamaan kuadrat memiliki pangkat tertinggi dua dengan koefisien utama bukan nol.',formula:'ax² + bx + c = 0, dengan a ≠ 0'},
        {heading:'2. Jumlah dan hasil kali akar',body:'Jika akar-akarnya x₁ dan x₂, hubungan ini sering lebih cepat daripada mencari kedua akar secara langsung.',formula:'x₁ + x₂ = −b/a  ·  x₁x₂ = c/a'},
        {heading:'3. Diskriminan',body:'Nilai diskriminan membantu memeriksa jenis akar real tanpa harus menghitung akar hingga selesai.',formula:'D = b² − 4ac  ·  D < 0: tidak ada akar real'}
      ],
      examples:[
        {label:'Normal',title:'Selesaikan x² − 5x + 6 = 0',question:'Carilah dua bilangan yang jumlahnya 5 dan hasil kalinya 6.',solution:['Faktorkan: (x − 2)(x − 3) = 0.','Maka x = 2 atau x = 3.']},
        {label:'Modifikasi',title:'Jumlah akar 2x² − 7x + 3 = 0',question:'Gunakan hubungan Vieta; akar tidak perlu dicari satu per satu.',solution:['a = 2 dan b = −7.','Jumlah akar = −b/a = −(−7)/2 = 7/2.']},
        {label:'Bergaya TKA',title:'Analisis akar x² + 4x + 5 = 0',question:'Gunakan diskriminan untuk menentukan apakah akar real ada.',solution:['D = b² − 4ac = 16 − 20 = −4.','Karena D < 0, persamaan tidak memiliki akar real.']}
      ],
      questions:[
        {id:'wk1',kind:'Normal',prompt:'Akar-akar persamaan x² − 5x + 6 = 0 adalah …',choices:['1 dan 6','−2 dan −3','2 dan 3','−1 dan −6','2 dan −3'],answer:2,explanation:'Persamaan dapat difaktorkan menjadi (x − 2)(x − 3) = 0, sehingga akarnya 2 dan 3.'},
        {id:'wk2',kind:'Normal',prompt:'Jumlah akar-akar persamaan 2x² − 7x + 3 = 0 adalah …',choices:['−7/2','−3/2','3/2','7/2','7'],answer:3,explanation:'Jumlah akar adalah −b/a. Di sini a = 2 dan b = −7, jadi jumlah akar = 7/2.'},
        {id:'wk3',kind:'Modifikasi',prompt:'Hasil kali akar-akar persamaan 3x² − x + 9 = 0 adalah …',choices:['−9','−3','1/3','9','3'],answer:4,explanation:'Hasil kali akar adalah c/a = 9/3 = 3.'},
        {id:'wk4',kind:'TKA · Penalaran',prompt:'Tanpa mencari nilai akar, apa yang dapat disimpulkan dari x² + 4x + 5 = 0?',choices:['Memiliki dua akar real berbeda','Memiliki satu akar real kembar','Tidak memiliki akar real','Kedua akar real positif','Kedua akar real negatif'],answer:2,explanation:'Diskriminan D = 4² − 4(1)(5) = 16 − 20 = −4. Diskriminan negatif berarti tidak ada akar real.'},
        {id:'wk5',kind:'Modifikasi',prompt:'Koordinat x titik puncak grafik y = x² − 6x + 5 adalah …',choices:['−6','−3','2','3','6'],answer:3,explanation:'Untuk y = ax² + bx + c, koordinat x titik puncak adalah −b/(2a). Di sini nilainya 6/2 = 3.'}
      ]
    },
    {
      id:'w-fungsi',track:'wajib',order:4,unit:'Fungsi',title:'Fungsi & Representasi',duration:13,difficulty:'Menengah',
      description:'Gunakan notasi fungsi, hitung nilai fungsi, dan baca domain serta range dari aturan sederhana.',
      objectives:['Menghitung nilai fungsi','Menentukan domain fungsi akar sederhana','Menafsirkan range fungsi kuadrat'],
      concepts:[
        {heading:'1. Notasi fungsi',body:'f(x) menyatakan keluaran fungsi f saat masukan x digunakan. Untuk mencari f(a), gantikan setiap x dengan a.',formula:'Jika f(x) = 2x − 3, maka f(4) = 2(4) − 3'},
        {heading:'2. Domain',body:'Domain adalah himpunan semua masukan yang diperbolehkan. Untuk akar kuadrat bilangan real, ekspresi di dalam akar harus tidak negatif.',formula:'√(x − 2) terdefinisi jika x − 2 ≥ 0'},
        {heading:'3. Range',body:'Range adalah semua nilai keluaran yang dapat dihasilkan. Untuk kuadrat dasar y = (x − h)² + k, nilai minimumnya k jika koefisien kuadrat positif.',formula:'(x − h)² ≥ 0'}
      ],
      examples:[
        {label:'Normal',title:'Jika f(x) = 2x − 3, cari f(4)',question:'Ganti x dengan 4.',solution:['f(4) = 2(4) − 3 = 8 − 3.','Jadi f(4) = 5.']},
        {label:'Modifikasi',title:'Domain g(x) = √(x − 2)',question:'Radikan harus bernilai paling sedikit nol untuk keluaran real.',solution:['x − 2 ≥ 0.','Tambahkan 2 ke kedua ruas: x ≥ 2.']},
        {label:'Bergaya TKA',title:'Range h(x) = (x − 1)²',question:'Pangkat dua tidak mungkin bernilai negatif dan dapat bernilai nol.',solution:['Karena (x − 1)² ≥ 0 untuk setiap x real.','Nilai 0 tercapai saat x = 1.','Range adalah y ≥ 0.']}
      ],
      questions:[
        {id:'wf1',kind:'Normal',prompt:'Jika f(x) = 2x − 3, nilai f(4) adalah …',choices:['3','4','5','6','8'],answer:2,explanation:'Substitusi x = 4 menghasilkan f(4) = 2(4) − 3 = 5.'},
        {id:'wf2',kind:'Normal',prompt:'Domain real dari g(x) = √(x − 2) adalah …',choices:['x ≤ 2','x ≥ 2','x > 0','semua bilangan real','x ≠ 2'],answer:1,explanation:'Radikan wajib memenuhi x − 2 ≥ 0, sehingga x ≥ 2.'},
        {id:'wf3',kind:'Modifikasi',prompt:'Range fungsi h(x) = (x − 1)² untuk x real adalah …',choices:['y ≤ 0','y ≥ 1','y > 0','y ≥ 0','semua bilangan real'],answer:3,explanation:'Kuadrat selalu tidak negatif dan mencapai nilai 0 saat x = 1. Jadi range-nya y ≥ 0.'},
        {id:'wf4',kind:'Modifikasi',prompt:'Diketahui g(x) = x² + 1. Nilai g(−2) adalah …',choices:['−5','−3','3','4','5'],answer:4,explanation:'g(−2) = (−2)² + 1 = 4 + 1 = 5.'},
        {id:'wf5',kind:'TKA · Penerapan',prompt:'Garis melalui (1, 3) dan (3, 7). Berapa gradiennya?',choices:['1','2','3','4','5'],answer:1,explanation:'Gradien m = (7 − 3)/(3 − 1) = 4/2 = 2.'}
      ]
    },
    {
      id:'w-statistika',track:'wajib',order:5,unit:'Data & Peluang',title:'Statistika & Peluang',duration:14,difficulty:'Menengah',
      description:'Ringkas sekumpulan data dengan ukuran pemusatan dan hitung peluang kejadian sederhana.',
      objectives:['Menghitung mean dan median','Menentukan modus','Menghitung peluang kejadian dasar'],
      concepts:[
        {heading:'1. Mean atau rata-rata',body:'Rata-rata diperoleh dengan menjumlahkan seluruh data lalu membaginya dengan banyak data.',formula:'Mean = jumlah seluruh data / banyak data'},
        {heading:'2. Median dan modus',body:'Median adalah nilai tengah setelah data diurutkan. Modus adalah nilai yang paling sering muncul.',formula:'Urutkan data sebelum menentukan median'},
        {heading:'3. Peluang',body:'Untuk hasil yang memiliki peluang sama, peluang kejadian adalah jumlah hasil yang mendukung dibagi jumlah seluruh hasil yang mungkin.',formula:'P(A) = n(A) / n(S)'}
      ],
      examples:[
        {label:'Normal',title:'Mean dari 4, 6, 8',question:'Jumlahkan data, lalu bagi dengan tiga.',solution:['Mean = (4 + 6 + 8)/3 = 18/3.','Hasilnya 6.']},
        {label:'Modifikasi',title:'Median dari 2, 3, 9, 10, 12',question:'Data telah diurutkan dan jumlah data ganjil.',solution:['Nilai tengah berada pada posisi ke-3.','Median = 9.']},
        {label:'Bergaya TKA',title:'Dua koin dilempar; peluang tepat satu sisi gambar',question:'Daftar hasil yang sama peluang: GG, GA, AG, AA.',solution:['Ada 4 hasil yang mungkin.','Tepat satu gambar terjadi pada GA dan AG, yaitu 2 hasil.','Peluang = 2/4 = 1/2.']}
      ],
      questions:[
        {id:'ws1',kind:'Normal',prompt:'Rata-rata dari data 4, 6, dan 8 adalah …',choices:['4','5','6','7','8'],answer:2,explanation:'Mean = (4 + 6 + 8)/3 = 18/3 = 6.'},
        {id:'ws2',kind:'Normal',prompt:'Median dari data terurut 2, 3, 9, 10, 12 adalah …',choices:['3','6','9','10','12'],answer:2,explanation:'Ada lima data. Nilai tengah adalah data ke-3, yaitu 9.'},
        {id:'ws3',kind:'Modifikasi',prompt:'Dua koin seimbang dilempar bersamaan. Peluang tepat satu sisi gambar adalah …',choices:['1/4','1/3','1/2','2/3','3/4'],answer:2,explanation:'Ada 4 hasil sama peluang. Dua hasil berisi tepat satu gambar: GA dan AG. Peluang = 2/4 = 1/2.'},
        {id:'ws4',kind:'TKA · Penerapan',prompt:'Sebuah dadu seimbang dilempar sekali. Peluang muncul angka lebih dari 4 adalah …',choices:['1/6','1/3','1/2','2/3','5/6'],answer:1,explanation:'Angka yang lebih dari 4 adalah 5 dan 6. Peluang = 2/6 = 1/3.'},
        {id:'ws5',kind:'Normal',prompt:'Modus dari data 2, 3, 3, 4, 5 adalah …',choices:['2','3','3,5','4','5'],answer:1,explanation:'Angka 3 muncul dua kali, lebih sering dibandingkan angka lainnya.'}
      ]
    },
    {
      id:'w-trigonometri',track:'wajib',order:6,unit:'Trigonometri',title:'Trigonometri Dasar',duration:14,difficulty:'Menengah',
      description:'Kuasai nilai sudut istimewa, identitas dasar, serta periode fungsi sinus dan cosinus.',
      objectives:['Mengingat nilai sudut istimewa','Menggunakan identitas trigonometri','Menentukan periode fungsi sinus sederhana'],
      concepts:[
        {heading:'1. Nilai sudut istimewa',body:'Sudut 30°, 45°, dan 60° sering muncul. Pahami hubungan nilai sinus, cosinus, dan tangen, bukan hanya menghafalnya.',formula:'sin 30° = 1/2  ·  cos 60° = 1/2'},
        {heading:'2. Identitas dasar',body:'Identitas ini berlaku untuk setiap x ketika fungsi terdefinisi dan sering digunakan untuk menyederhanakan ekspresi.',formula:'sin²x + cos²x = 1'},
        {heading:'3. Periode',body:'Untuk sudut dalam derajat, periode dasar sin(kx) atau cos(kx) adalah 360°/|k| apabila k bukan nol.',formula:'T = 360° / |k|'}
      ],
      examples:[
        {label:'Normal',title:'Nilai sin 30°',question:'Gunakan segitiga istimewa 30°–60°–90°.',solution:['Perbandingan sisi di depan 30° terhadap hipotenusa adalah 1 : 2.','Jadi sin 30° = 1/2.']},
        {label:'Modifikasi',title:'Periode f(x) = 3 sin(2x)',question:'Koefisien x di dalam sinus adalah 2.',solution:['T = 360°/|2|.','Periode = 180°.']},
        {label:'Bergaya TKA',title:'Jika tan θ = 3/4 dan θ lancip',question:'Gunakan perbandingan sisi segitiga siku-siku 3–4–5.',solution:['Sisi depan = 3, sisi samping = 4, hipotenusa = 5.','sin θ = sisi depan/hipotenusa = 3/5.']}
      ],
      questions:[
        {id:'wt1',kind:'Normal',prompt:'Nilai sin 30° adalah …',choices:['0','1/2','√2/2','√3/2','1'],answer:1,explanation:'Pada sudut istimewa 30°, nilai sinus adalah 1/2.'},
        {id:'wt2',kind:'Normal',prompt:'Nilai cos 60° adalah …',choices:['0','1/2','√2/2','√3/2','1'],answer:1,explanation:'Pada sudut istimewa 60°, nilai cosinus adalah 1/2.'},
        {id:'wt3',kind:'Modifikasi',prompt:'Periode f(x) = 3 sin(2x), jika x dalam derajat, adalah …',choices:['60°','90°','120°','180°','360°'],answer:3,explanation:'Periode sin(kx) adalah 360°/|k|. Untuk k = 2, periodenya 180°.'},
        {id:'wt4',kind:'TKA · Penerapan',prompt:'Jika tan θ = 3/4 dan θ lancip, maka sin θ = …',choices:['3/4','4/5','3/5','5/3','4/3'],answer:2,explanation:'Sisi depan dan samping dapat dianggap 3 dan 4, sehingga hipotenusa √(3²+4²) = 5. Maka sin θ = 3/5.'},
        {id:'wt5',kind:'Normal',prompt:'Identitas yang benar untuk setiap x adalah …',choices:['sin x + cos x = 1','sin²x − cos²x = 1','sin²x + cos²x = 1','tan x = sin x · cos x','cos x = 1/sin x'],answer:2,explanation:'Identitas Pythagoras trigonometri menyatakan sin²x + cos²x = 1.'}
      ]
    },

    {
      id:'w-geometri',track:'wajib',order:7,unit:'Geometri & Pengukuran',title:'Geometri & Pengukuran',duration:14,difficulty:'Fondasi → Menengah',
      description:'Gunakan rumus luas, jarak, keliling lingkaran, serta skala untuk menyelesaikan persoalan geometri.',
      objectives:['Menghitung luas segitiga','Menggunakan jarak dua titik dan teorema Pythagoras','Menafsirkan skala dan ukuran lingkaran'],
      concepts:[
        {heading:'1. Luas segitiga',body:'Luas segitiga sama dengan setengah hasil kali alas dan tinggi yang tegak lurus terhadap alas.',formula:'L = 1/2 × alas × tinggi'},
        {heading:'2. Jarak dan Pythagoras',body:'Jarak dua titik pada bidang dapat dihitung memakai selisih koordinat dan teorema Pythagoras. Pada segitiga siku-siku, kuadrat hipotenusa adalah jumlah kuadrat dua sisi siku-sikunya.',formula:'d = √((x₂ − x₁)² + (y₂ − y₁)²)'},
        {heading:'3. Lingkaran dan skala',body:'Keliling lingkaran adalah 2πr. Pada gambar berskala 1 : n, satu satuan panjang pada gambar mewakili n satuan panjang sebenarnya.',formula:'K = 2πr  ·  ukuran sebenarnya = n × ukuran gambar'}
      ],
      examples:[
        {label:'Normal',title:'Luas segitiga beralas 10 dan tinggi 6',question:'Masukkan alas dan tinggi ke dalam rumus.',solution:['L = 1/2 × 10 × 6.','Luasnya 30 satuan².']},
        {label:'Modifikasi',title:'Jarak titik (1, 2) dan (4, 6)',question:'Gunakan selisih koordinat pada rumus jarak.',solution:['d = √((4−1)² + (6−2)²).','d = √(9 + 16) = √25 = 5.']},
        {label:'Bergaya TKA',title:'Skala denah 1 : 200',question:'Panjang gambar 5 cm. Berapa panjang sebenarnya?',solution:['Panjang sebenarnya = 5 × 200 = 1.000 cm.','1.000 cm = 10 meter.']}
      ],
      questions:[
        {id:'wg1',kind:'Normal',prompt:'Segitiga memiliki alas 10 cm dan tinggi 6 cm. Luasnya adalah …',choices:['16 cm²','30 cm²','60 cm²','80 cm²','120 cm²'],answer:1,explanation:'Luas = 1/2 × alas × tinggi = 1/2 × 10 × 6 = 30 cm².'},
        {id:'wg2',kind:'Modifikasi',prompt:'Jarak antara titik (1, 2) dan (4, 6) adalah … satuan.',choices:['3','4','5','6','7'],answer:2,explanation:'Jarak = √((4−1)²+(6−2)²) = √(9+16) = √25 = 5.'},
        {id:'wg3',kind:'Normal',prompt:'Keliling lingkaran dengan jari-jari 7 cm adalah …',choices:['7π cm','14π cm','28π cm','49π cm','98π cm'],answer:1,explanation:'Keliling = 2πr = 2π(7) = 14π cm.'},
        {id:'wg4',kind:'Modifikasi',prompt:'Segitiga siku-siku memiliki sisi siku-siku 6 cm dan 8 cm. Panjang hipotenusanya adalah …',choices:['7 cm','8 cm','9 cm','10 cm','14 cm'],answer:3,explanation:'Dengan Pythagoras, c = √(6²+8²) = √100 = 10 cm.'},
        {id:'wg5',kind:'TKA · Penerapan',prompt:'Pada denah berskala 1 : 200, sebuah koridor digambar sepanjang 5 cm. Panjang sebenarnya adalah …',choices:['2 m','5 m','8 m','10 m','20 m'],answer:3,explanation:'Panjang sebenarnya = 5×200 = 1.000 cm = 10 m.'}
      ]
    },
    {
      id:'l-matriks',track:'lanjut',order:1,unit:'Aljabar',title:'Matriks & Determinan',duration:16,difficulty:'Menengah',
      description:'Kenali operasi matriks, determinan ordo 2 × 2, invers, dan syarat sebuah matriks memiliki invers.',
      objectives:['Menghitung determinan matriks 2 × 2','Melakukan operasi penjumlahan matriks','Mengenali matriks singular dan invers'],
      concepts:[
        {heading:'1. Determinan matriks 2 × 2',body:'Untuk matriks persegi berordo dua, determinan diperoleh dari hasil kali diagonal utama dikurangi hasil kali diagonal lainnya.',formula:'det [[a, b], [c, d]] = ad − bc'},
        {heading:'2. Penjumlahan matriks',body:'Matriks dapat dijumlahkan jika ukurannya sama. Tambahkan elemen yang berada pada posisi bersesuaian.',formula:'(A + B)ᵢⱼ = Aᵢⱼ + Bᵢⱼ'},
        {heading:'3. Invers',body:'Matriks persegi memiliki invers jika determinannya tidak sama dengan nol. Untuk matriks 2 × 2, gunakan rumus berikut.',formula:'A⁻¹ = 1/(ad − bc) [[d, −b], [−c, a]]'}
      ],
      examples:[
        {label:'Normal',title:'Determinan [[2, 1], [3, 4]]',question:'Gunakan rumus ad − bc.',solution:['det A = (2)(4) − (1)(3).','det A = 8 − 3 = 5.']},
        {label:'Modifikasi',title:'Invers [[2, 1], [1, 1]]',question:'Determinan matriks ini adalah 2(1) − 1(1) = 1.',solution:['Tukar elemen diagonal dan ubah tanda elemen di luar diagonal.','A⁻¹ = [[1, −1], [−1, 2]] karena determinannya 1.']},
        {label:'Bergaya TKA',title:'Apakah [[1, 2], [2, 4]] memiliki invers?',question:'Periksa nilai determinan terlebih dahulu.',solution:['det A = (1)(4) − (2)(2) = 0.','Karena determinan nol, matriks tersebut singular dan tidak memiliki invers.']}
      ],
      questions:[
        {id:'lm1',kind:'Normal',prompt:'Determinan matriks [[2, 1], [3, 4]] adalah …',choices:['−5','−2','3','5','11'],answer:3,explanation:'det A = (2)(4) − (1)(3) = 8 − 3 = 5.'},
        {id:'lm2',kind:'Normal',prompt:'Jika A = [[1, 2], [0, 3]] dan B = [[2, 1], [4, 0]], maka A + B = …',choices:['[[3, 3], [4, 3]]','[[2, 2], [4, 0]]','[[3, 1], [4, 3]]','[[1, 3], [4, 3]]','[[3, 3], [0, 3]]'],answer:0,explanation:'Jumlahkan elemen yang seposisi: [[1+2, 2+1], [0+4, 3+0]] = [[3, 3], [4, 3]].'},
        {id:'lm3',kind:'Modifikasi',prompt:'Invers matriks [[2, 1], [1, 1]] adalah …',choices:['[[1, 1], [1, 2]]','[[2, −1], [−1, 1]]','[[1, −1], [−1, 2]]','[[1, 2], [−1, 1]]','[[2, 1], [1, 1]]'],answer:2,explanation:'Determinan = 1. Tukar elemen diagonal dan ubah tanda elemen luar diagonal sehingga inversnya [[1, −1], [−1, 2]].'},
        {id:'lm4',kind:'TKA · Penalaran',prompt:'Matriks [[1, 2], [2, 4]] tidak memiliki invers karena …',choices:['Matriksnya berordo 2 × 2','Semua elemennya positif','Determinan sama dengan nol','Elemen diagonalnya berbeda','Memiliki empat elemen'],answer:2,explanation:'Determinan = 1×4 − 2×2 = 0. Matriks persegi memiliki invers hanya jika determinannya tidak nol.'},
        {id:'lm5',kind:'Modifikasi',prompt:'Jika A matriks persegi dan det(A) ≠ 0, pernyataan yang pasti benar adalah …',choices:['A tidak memiliki invers','A memiliki invers','Semua elemen A positif','A adalah matriks nol','det(A) = 0'],answer:1,explanation:'Syarat perlu dan cukup untuk matriks persegi memiliki invers adalah determinannya tidak nol.'}
      ]
    },
    {
      id:'l-polinomial',track:'lanjut',order:2,unit:'Aljabar',title:'Polinomial & Suku Sisa',duration:15,difficulty:'Menengah',
      description:'Latih operasi dan pemfaktoran polinomial, derajat polinom, serta teorema sisa untuk pembagian dengan x − a.',
      objectives:['Menentukan derajat polinomial','Memfaktorkan polinomial kuadrat','Menggunakan teorema sisa'],
      concepts:[
        {heading:'1. Derajat polinomial',body:'Derajat polinomial satu variabel adalah pangkat tertinggi dengan koefisien bukan nol setelah bentuk disederhanakan.',formula:'deg(x² + 3x + 1) = 2'},
        {heading:'2. Teorema sisa',body:'Jika polinomial P(x) dibagi oleh x − a, sisanya adalah P(a). Cara ini menghindarkan pembagian panjang ketika yang dicari hanya sisa.',formula:'Sisa pembagian P(x) oleh (x − a) = P(a)'},
        {heading:'3. Faktor polinomial',body:'Jika P(a) = 0, maka (x − a) merupakan faktor P(x). Hubungkan teorema faktor dengan substitusi nilai akar.',formula:'P(a) = 0 ⇔ (x − a) faktor dari P(x)'}
      ],
      examples:[
        {label:'Normal',title:'Faktorkan x² − 5x + 6',question:'Cari dua bilangan dengan hasil kali 6 dan jumlah −5.',solution:['Dua bilangan tersebut adalah −2 dan −3.','Hasil faktorisasi: (x − 2)(x − 3).']},
        {label:'Modifikasi',title:'Sisa P(x) = x³ − 2x + 5 dibagi x − 2',question:'Substitusikan x = 2 ke P(x).',solution:['P(2) = 2³ − 2(2) + 5.','P(2) = 8 − 4 + 5 = 9.','Sisanya 9.']},
        {label:'Bergaya TKA',title:'Tentukan derajat (x² + 1)(x³ − 2)',question:'Pangkat tertinggi muncul dari hasil perkalian suku berpangkat tertinggi.',solution:['Suku berpangkat tertinggi adalah x² · x³ = x⁵.','Tidak ada suku lain yang dapat menghapus suku x⁵ ini.','Derajat hasil kali adalah 5.']}
      ],
      questions:[
        {id:'lp1',kind:'Normal',prompt:'Faktorisasi x² − 5x + 6 adalah …',choices:['(x + 2)(x + 3)','(x − 2)(x − 3)','(x − 1)(x − 6)','(x + 1)(x − 6)','(x − 2)(x + 3)'],answer:1,explanation:'Dua bilangan yang hasil kalinya 6 dan jumlahnya −5 adalah −2 dan −3.'},
        {id:'lp2',kind:'Normal',prompt:'Sisa pembagian P(x) = x³ − 2x + 5 oleh (x − 2) adalah …',choices:['3','5','7','8','9'],answer:4,explanation:'Menurut teorema sisa, sisanya P(2) = 8 − 4 + 5 = 9.'},
        {id:'lp3',kind:'Modifikasi',prompt:'Derajat polinomial (x² + 1)(x³ − 2) adalah …',choices:['2','3','4','5','6'],answer:3,explanation:'Pangkat utama dari hasil kali adalah x² · x³ = x⁵, sehingga derajatnya 5.'},
        {id:'lp4',kind:'TKA · Penalaran',prompt:'Jika P(1) = 0, faktor yang pasti dimiliki polinomial P(x) adalah …',choices:['x + 1','x² + 1','x − 1','x','1 − x²'],answer:2,explanation:'Menurut teorema faktor, P(a) = 0 berarti (x − a) merupakan faktor. Untuk a = 1, faktornya x − 1.'},
        {id:'lp5',kind:'Modifikasi',prompt:'Koefisien utama dari P(x) = 2x³ + x − 4 adalah …',choices:['−4','1','2','3','x³'],answer:2,explanation:'Suku berderajat tertinggi adalah 2x³, jadi koefisien utamanya 2.'}
      ]
    },
    {
      id:'l-fungsi',track:'lanjut',order:3,unit:'Aljabar',title:'Fungsi & Grafik Lanjutan',duration:17,difficulty:'Menengah → Lanjut',
      description:'Pelajari domain, range, komposisi fungsi, dan periode fungsi trigonometri dalam konteks penalaran.',
      objectives:['Memeriksa domain fungsi rasional sederhana','Menghitung komposisi fungsi','Menentukan periode fungsi trigonometri'],
      concepts:[
        {heading:'1. Domain fungsi rasional',body:'Penyebut pecahan tidak boleh sama dengan nol. Cari nilai yang membuat penyebut nol, lalu keluarkan nilai itu dari domain.',formula:'f(x) = 1/(x − 2) ⇒ x ≠ 2'},
        {heading:'2. Komposisi fungsi',body:'Komposisi (f ∘ g)(x) berarti memasukkan keluaran g(x) ke dalam fungsi f. Urutan operasi penting.',formula:'(f ∘ g)(x) = f(g(x))'},
        {heading:'3. Periode trigonometri',body:'Periode fungsi sinus dan cosinus dalam derajat bergantung pada koefisien sudutnya. Koefisien di luar fungsi mengubah amplitudo, bukan periode.',formula:'sin(kx): T = 360° / |k|'}
      ],
      examples:[
        {label:'Normal',title:'Domain f(x) = 1/(x − 2)',question:'Nilai yang membuat penyebut nol harus dikeluarkan.',solution:['x − 2 ≠ 0.','Jadi x ≠ 2.']},
        {label:'Modifikasi',title:'Komposisi f(g(x))',question:'Jika f(x) = 2x dan g(x) = x + 3, tentukan f(g(x)).',solution:['Masukkan g(x) = x + 3 ke f.','f(g(x)) = 2(x + 3) = 2x + 6.']},
        {label:'Bergaya TKA',title:'Periode y = −3 sin(2x − 30°) + 4',question:'Koefisien x adalah 2; pergeseran fase dan perubahan amplitudo tidak mengubah periode.',solution:['Periode = 360°/2.','Periode fungsi = 180°.']}
      ],
      questions:[
        {id:'lf1',kind:'Normal',prompt:'Domain real fungsi f(x) = 1/(x − 2) adalah …',choices:['semua x','x = 2','x ≠ 2','x > 2','x < 2'],answer:2,explanation:'Penyebut tidak boleh nol, sehingga x − 2 ≠ 0 atau x ≠ 2.'},
        {id:'lf2',kind:'Normal',prompt:'Jika f(x) = 2x dan g(x) = x + 3, maka (f ∘ g)(x) = …',choices:['2x + 3','2x + 6','x + 5','2x − 6','x² + 3'],answer:1,explanation:'f(g(x)) = 2(x + 3) = 2x + 6.'},
        {id:'lf3',kind:'Modifikasi',prompt:'Periode y = −3 sin(2x − 30°) + 4, untuk x dalam derajat, adalah …',choices:['30°','90°','120°','180°','360°'],answer:3,explanation:'Koefisien x adalah 2. Periode = 360°/2 = 180°. Fase, amplitudo, dan pergeseran vertikal tidak mengubah periode.'},
        {id:'lf4',kind:'TKA · Penerapan',prompt:'Fungsi f memiliki domain semua bilangan real. Agar g(x) = √(f(x)) real, syarat yang harus berlaku adalah …',choices:['f(x) < 0','f(x) ≠ 0 saja','f(x) ≤ 0','f(x) ≥ 0','x ≥ 0 selalu'],answer:3,explanation:'Akar kuadrat real mensyaratkan nilai di dalam akar tidak negatif, yaitu f(x) ≥ 0.'},
        {id:'lf5',kind:'Modifikasi',prompt:'Perubahan 2 sin x menjadi 5 sin x mengubah …',choices:['periode saja','amplitudo saja','domain menjadi x ≥ 0','periode dan domain','tidak mengubah grafik'],answer:1,explanation:'Koefisien di luar fungsi mengubah amplitudo dari 2 menjadi 5, tetapi tidak mengubah periode dasar sin x.'}
      ]
    },
    {
      id:'l-vektor',track:'lanjut',order:4,unit:'Geometri & Pengukuran',title:'Vektor pada Bidang & Ruang',duration:16,difficulty:'Menengah',
      description:'Operasikan vektor, hitung panjang vektor, dan gunakan perkalian titik untuk menganalisis hubungan vektor.',
      objectives:['Menjumlahkan dan mengurangkan vektor','Menghitung panjang vektor','Menentukan hasil perkalian titik'],
      concepts:[
        {heading:'1. Operasi komponen',body:'Jumlahkan atau kurangkan komponen yang bersesuaian. Semua vektor yang dioperasikan harus memiliki dimensi yang sama.',formula:'(a, b) + (c, d) = (a + c, b + d)'},
        {heading:'2. Panjang vektor',body:'Panjang vektor berasal dari teorema Pythagoras dan merupakan bilangan tidak negatif.',formula:'|(a, b)| = √(a² + b²)'},
        {heading:'3. Perkalian titik',body:'Kalikan setiap pasangan komponen yang bersesuaian lalu jumlahkan hasilnya. Perkalian titik menghasilkan skalar.',formula:'u · v = u₁v₁ + u₂v₂ + ⋯ + uₙvₙ'}
      ],
      examples:[
        {label:'Normal',title:'Panjang vektor (3, 4)',question:'Gunakan teorema Pythagoras.',solution:['|(3, 4)| = √(3² + 4²).','Panjang = √25 = 5.']},
        {label:'Modifikasi',title:'Jumlahkan (1, 2) dan (3, −1)',question:'Jumlahkan masing-masing komponen.',solution:['(1, 2) + (3, −1) = (1 + 3, 2 − 1).','Hasilnya (4, 1).']},
        {label:'Bergaya TKA',title:'Perkalian titik (1, 2, 3) · (2, 0, −1)',question:'Kalikan pasangan komponen, lalu jumlahkan.',solution:['1×2 + 2×0 + 3×(−1) = 2 + 0 − 3.','Hasilnya −1.']}
      ],
      questions:[
        {id:'lv1',kind:'Normal',prompt:'Panjang vektor (3, 4) adalah …',choices:['3','4','5','7','25'],answer:2,explanation:'Panjang = √(3² + 4²) = √25 = 5.'},
        {id:'lv2',kind:'Normal',prompt:'(1, 2) + (3, −1) sama dengan …',choices:['(2, 1)','(4, 1)','(4, 3)','(−2, 3)','(3, 2)'],answer:1,explanation:'Jumlahkan komponen: (1+3, 2−1) = (4, 1).'},
        {id:'lv3',kind:'Modifikasi',prompt:'Hasil perkalian titik (1, 2, 3) · (2, 0, −1) adalah …',choices:['−3','−1','0','2','5'],answer:1,explanation:'1×2 + 2×0 + 3×(−1) = 2 − 3 = −1.'},
        {id:'lv4',kind:'TKA · Penalaran',prompt:'Jika u = (2, −1) dan v = (3, 4), maka u − v adalah …',choices:['(5, 3)','(1, 5)','(−1, −5)','(−5, 3)','(6, −4)'],answer:2,explanation:'Kurangkan komponen: (2−3, −1−4) = (−1, −5).'},
        {id:'lv5',kind:'Penerapan',prompt:'Sebuah segitiga luasnya 10 satuan². Setelah dilatasi berpusat di O dengan faktor skala 3, luasnya menjadi …',choices:['30','60','90','100','300'],answer:2,explanation:'Luas berubah dengan kuadrat faktor skala. Luas baru = 3² × 10 = 90.'}
      ]
    },
    {
      id:'l-transformasi',track:'lanjut',order:5,unit:'Geometri & Pengukuran',title:'Transformasi Geometri',duration:15,difficulty:'Menengah → Lanjut',
      description:'Pahami translasi, refleksi, dilatasi, dan dampak transformasi terhadap koordinat serta luas bangun.',
      objectives:['Menerapkan translasi titik','Mengenali refleksi terhadap sumbu','Menghubungkan faktor dilatasi dan luas'],
      concepts:[
        {heading:'1. Translasi',body:'Translasi menggeser titik dengan menambahkan vektor pergeseran pada koordinatnya.',formula:'(x, y) → (x + a, y + b)'},
        {heading:'2. Refleksi',body:'Refleksi mencerminkan titik. Refleksi terhadap sumbu-y mengubah tanda koordinat x, sementara koordinat y tetap.',formula:'Refleksi sumbu-y: (x, y) → (−x, y)'},
        {heading:'3. Dilatasi',body:'Dilatasi berpusat di titik asal dengan faktor k mengalikan koordinat dengan k. Luas berubah dengan faktor k².',formula:'(x, y) → (kx, ky)  ·  L baru = k² × L awal'}
      ],
      examples:[
        {label:'Normal',title:'Translasi titik (3, 4) oleh (2, −1)',question:'Tambahkan komponen vektor translasi.',solution:['(3, 4) → (3+2, 4−1).','Bayangannya (5, 3).']},
        {label:'Modifikasi',title:'Refleksi (−2, 5) terhadap sumbu-y',question:'Ubah tanda koordinat x dan pertahankan y.',solution:['(x, y) → (−x, y).','(−2, 5) → (2, 5).']},
        {label:'Bergaya TKA',title:'Dampak dilatasi skala 3 pada luas',question:'Luas berubah menurut kuadrat faktor skala.',solution:['Faktor luas = 3² = 9.','Jika luas awal 10 satuan², luas baru 9×10 = 90 satuan².']}
      ],
      questions:[
        {id:'lt1',kind:'Normal',prompt:'Titik (3, 4) ditranslasikan oleh vektor (2, −1). Bayangannya adalah …',choices:['(1, 5)','(5, 3)','(−5, 3)','(3, 2)','(6, −4)'],answer:1,explanation:'Tambahkan komponen vektor: (3+2, 4−1) = (5, 3).'},
        {id:'lt2',kind:'Normal',prompt:'Bayangan titik (−2, 5) oleh refleksi terhadap sumbu-y adalah …',choices:['(−2, −5)','(2, −5)','(2, 5)','(−5, 2)','(5, −2)'],answer:2,explanation:'Refleksi terhadap sumbu-y mengubah x menjadi −x dan mempertahankan y. Jadi (−2, 5) → (2, 5).'},
        {id:'lt3',kind:'Modifikasi',prompt:'Bangun seluas 10 satuan² didilatasi dengan pusat O dan faktor skala 3. Luas bayangannya adalah …',choices:['13','30','60','90','300'],answer:3,explanation:'Luas dikalikan kuadrat faktor skala: 10×3² = 90 satuan².'},
        {id:'lt4',kind:'TKA · Penalaran',prompt:'Titik (2, −3) didilatasi berpusat di O dengan faktor −2. Bayangannya adalah …',choices:['(4, −6)','(−4, 6)','(−4, −6)','(0, −6)','(2, 6)'],answer:1,explanation:'Kalikan setiap koordinat dengan −2: (2, −3) → (−4, 6).'},
        {id:'lt5',kind:'Penerapan',prompt:'Transformasi (x, y) → (x, −y) merupakan refleksi terhadap …',choices:['sumbu-x','sumbu-y','garis y = x','titik asal saja','garis y = −x'],answer:0,explanation:'Refleksi terhadap sumbu-x mempertahankan x dan mengubah tanda koordinat y.'}
      ]
    },
    {
      id:'l-limit',track:'lanjut',order:6,unit:'Kalkulus',title:'Limit Fungsi',duration:17,difficulty:'Menengah → Lanjut',
      description:'Gunakan substitusi langsung dan pemfaktoran untuk menentukan limit fungsi aljabar sederhana.',
      objectives:['Menguji substitusi langsung','Mengatasi bentuk 0/0 dengan faktorisasi','Membedakan nilai fungsi dan nilai limit'],
      concepts:[
        {heading:'1. Substitusi langsung',body:'Jika fungsi kontinu pada titik yang dituju dan substitusi menghasilkan nilai terdefinisi, masukkan nilai tersebut langsung.',formula:'limₓ→a f(x) = f(a) untuk fungsi kontinu'},
        {heading:'2. Bentuk 0/0',body:'Bentuk 0/0 belum memberikan nilai limit. Coba faktorkan pembilang dan sederhanakan faktor yang sama sebelum substitusi kembali.',formula:'(x² − a²)/(x − a) = x + a, untuk x ≠ a'},
        {heading:'3. Urutan penyelesaian',body:'Faktorkan dengan benar, sederhanakan ekspresi untuk x yang berada di sekitar titik, lalu evaluasi bentuk yang tersisa. Jangan menggunakan Teorema L’Hôpital untuk soal fondasi ini.'}
      ],
      examples:[
        {label:'Normal',title:'lim x→2 (2x² + 3x − 1)',question:'Polinomial kontinu, sehingga gunakan substitusi langsung.',solution:['2(2²) + 3(2) − 1 = 8 + 6 − 1.','Hasil limit = 13.']},
        {label:'Modifikasi',title:'lim x→3 (x² − 9)/(x − 3)',question:'Substitusi langsung menghasilkan 0/0; faktorkan pembilang.',solution:['x² − 9 = (x − 3)(x + 3).','Untuk x ≠ 3, ekspresi menyederhana menjadi x + 3.','Limit = 3 + 3 = 6.']},
        {label:'Bergaya TKA',title:'lim x→−2 (x² − 4)/(x + 2)',question:'Faktorkan selisih kuadrat lalu sederhanakan.',solution:['x² − 4 = (x − 2)(x + 2).','Ekspresi menyederhana menjadi x − 2 untuk x ≠ −2.','Limit = −2 − 2 = −4.']}
      ],
      questions:[
        {id:'ll1',kind:'Normal',prompt:'Nilai lim x→3 (x² − 9)/(x − 3) adalah …',choices:['−6','−3','0','3','6'],answer:4,explanation:'Faktorkan x²−9 = (x−3)(x+3), sederhanakan, lalu substitusi x=3. Nilainya 6.'},
        {id:'ll2',kind:'Normal',prompt:'Nilai lim x→2 (x² − 4)/(x − 2) adalah …',choices:['−4','0','2','4','6'],answer:3,explanation:'x²−4 = (x−2)(x+2). Setelah menyederhanakan, substitusi x=2 memberi 4.'},
        {id:'ll3',kind:'Modifikasi',prompt:'Nilai lim x→2 (2x² + 3x − 1) adalah …',choices:['7','9','11','13','15'],answer:3,explanation:'Polinomial kontinu. Substitusi x=2 memberi 2(4)+3(2)−1 = 13.'},
        {id:'ll4',kind:'Modifikasi',prompt:'Nilai lim x→1 (x² − 1)/(x − 1) adalah …',choices:['0','1','2','3','tidak ada'],answer:2,explanation:'x²−1 = (x−1)(x+1). Setelah menyederhanakan, nilai limit adalah 1+1 = 2.'},
        {id:'ll5',kind:'TKA · Penalaran',prompt:'Nilai lim x→−2 (x² − 4)/(x + 2) adalah …',choices:['−4','−2','0','2','4'],answer:0,explanation:'x²−4 = (x−2)(x+2). Ekspresi menyederhana menjadi x−2, lalu x→−2 memberi −4.'}
      ]
    }
  ];
  return Object.freeze(lessons.map(lesson => Object.freeze({ ...lesson, objectives: Object.freeze(lesson.objectives), concepts: Object.freeze(lesson.concepts), examples: Object.freeze(lesson.examples), questions: Object.freeze(lesson.questions) })));
});
